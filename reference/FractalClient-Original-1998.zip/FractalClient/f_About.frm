VERSION 5.00
Begin VB.Form f_About 
   BorderStyle     =   3  'Fester Dialog
   Caption         =   "�ber..."
   ClientHeight    =   1605
   ClientLeft      =   2340
   ClientTop       =   1935
   ClientWidth     =   4110
   ClipControls    =   0   'False
   Icon            =   "f_About.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1107.8
   ScaleMode       =   0  'Benutzerdefiniert
   ScaleWidth      =   3859.502
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   345
      Left            =   2760
      TabIndex        =   0
      Top             =   1200
      Width           =   1260
   End
   Begin VB.Label lblDescription 
      Caption         =   "Studienarbeit Graphische Oberfl�chenprogrammierung von Martin Zapf und Martin Busch"
      ForeColor       =   &H00000000&
      Height          =   480
      Left            =   120
      TabIndex        =   1
      Top             =   450
      Width           =   3885
   End
   Begin VB.Label lblTitle 
      Caption         =   "FractalClient f�r FractalServer"
      ForeColor       =   &H00000000&
      Height          =   240
      Left            =   120
      TabIndex        =   2
      Top             =   90
      Width           =   3885
   End
End
Attribute VB_Name = "f_About"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
' File:       f_About
' Desc:       Info �ber das Programm
' Author:     Martin Zapf
' Modified:   29.11.98 22:14
'
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Private Sub cmdOK_Click()
  Unload Me
End Sub

