VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form f_Status 
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "FractalClient Status"
   ClientHeight    =   1770
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5430
   Icon            =   "f_Status.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1770
   ScaleWidth      =   5430
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'Fenstermitte
   Begin VB.Frame FrameThreadStart 
      Caption         =   "Threads"
      Height          =   1005
      Left            =   150
      TabIndex        =   1
      Top             =   60
      Width           =   5145
      Begin VB.TextBox el_ThreadNrReturn 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   3840
         Locked          =   -1  'True
         TabIndex        =   8
         Top             =   300
         Width           =   1215
      End
      Begin VB.TextBox el_ThreadNrStart 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   1410
         Locked          =   -1  'True
         TabIndex        =   7
         Top             =   330
         Width           =   1215
      End
      Begin VB.TextBox el_ThreadsReturned 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   3840
         Locked          =   -1  'True
         TabIndex        =   5
         Top             =   600
         Width           =   1215
      End
      Begin VB.TextBox el_ThreadsRunning 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   1410
         Locked          =   -1  'True
         TabIndex        =   4
         Top             =   630
         Width           =   1215
      End
      Begin VB.Label Label4 
         Caption         =   "beende Thread:"
         Height          =   225
         Left            =   2670
         TabIndex        =   9
         Top             =   330
         Width           =   1185
      End
      Begin VB.Label Label3 
         Caption         =   "starte Thread:"
         Height          =   225
         Left            =   390
         TabIndex        =   6
         Top             =   330
         Width           =   1065
      End
      Begin VB.Label Label2 
         Caption         =   "Server returns:"
         Height          =   285
         Left            =   2760
         TabIndex        =   3
         Top             =   630
         Width           =   1155
      End
      Begin VB.Label Label1 
         Caption         =   "laufende Threads:"
         Height          =   225
         Left            =   90
         TabIndex        =   2
         Top             =   630
         Width           =   1425
      End
   End
   Begin MSComctlLib.ProgressBar ProgressBar 
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   1350
      Width           =   5175
      _ExtentX        =   9128
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
      Scrolling       =   1
   End
   Begin VB.Label l_Progress 
      Height          =   225
      Left            =   990
      TabIndex        =   11
      Top             =   1140
      Width           =   4275
   End
   Begin VB.Label Label7 
      Caption         =   "Fortschritt: "
      Height          =   285
      Left            =   120
      TabIndex        =   10
      Top             =   1140
      Width           =   825
   End
End
Attribute VB_Name = "f_Status"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
' File:       f_Status
' Desc:       Form f�r die Anzeige des Berechnung-Status
' Author:     Martin Zapf
' Modified:   29.11.98 19:35
'
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Private Sub Form_Unload(Cancel As Integer)
  f_main.m_ShowStatus.Checked = False
End Sub

