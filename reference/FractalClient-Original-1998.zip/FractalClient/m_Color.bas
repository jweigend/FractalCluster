Attribute VB_Name = "m_Color"
'
' File:       m_Color
' Desc:       zur Farbberechnung
' Author:     Martin Busch
' Modified:   07.12.98 2:45
'
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Public Sub Create_Color_Table(anzahl, ByRef farben)
  Dim i, j, factor#, r1, g1, b1, r2, g2, b2
  Dim zaehler&, rot%, gr�n%, blau%
  Dim coloroffset%, colorchange%
  
  coloroffset = Param.coloroffset
  colorchange = Param.colorchange
  ReDim farben(anzahl)     'dieses Feld wird zum Zeichnen verwendet
  ReDim farb(12) As Long   'das ist nur ein Hilfsfeld
  farb(0) = 5
  farb(1) = 1
  farb(2) = 9
  farb(3) = 3
  farb(4) = 11
  farb(5) = 14
  farb(6) = 10
  farb(7) = 2
  farb(8) = 10
  farb(9) = 14
  farb(10) = 12
  farb(11) = 13
  If Param.colordepth = 1 Then           ' Farbtabelle f�r S/W-Farbgrafik
    For i = 1 To anzahl
      If (i Mod 2) = 1 Then
        farben(i) = RGB(255, 255, 255)  'wei�
      Else
        farben(i) = 0                   'schwarz
      End If
    Next i
  ElseIf Param.colordepth = 4 Then     ' Farbtabelle f�r 16-Farbgrafik
    For i = 0 To 11
      farb(i) = QBColor(farb(i))
    Next i
    For i = 1 To anzahl
      farben(i) = farb(((i / colorchange + i Mod 3) + coloroffset) Mod 12)
    Next i
  Else  ' mehr als 16 Farben: kontinuierlicher Farben�bergang
    farben(0) = 0  'Hintergrund schwarz
    zaehler = 1
    For i = 0 To 11
      farb(i) = QBColor(farb(i))
    Next i
    Do
      For i = 0 To 11
        r1 = farb((i + coloroffset) Mod 12) And 255&
        g1 = Int(farb((i + coloroffset) Mod 12) / 256) And 255&
        b1 = Int(farb((i + coloroffset) Mod 12) / 65536) And 255&
        r2 = farb((i + coloroffset + 1) Mod 12) And 255&
        g2 = Int(farb((i + coloroffset + 1) Mod 12) / 256) And 255&
        b2 = Int(farb((i + coloroffset + 1) Mod 12) / 65536) And 255&
        For j = 0 To colorchange - 1
          factor = j / colorchange
          rot = r1 * (1 - factor) + r2 * factor
          gr�n = g1 * (1 - factor) + g2 * factor
          blau = b1 * (1 - factor) + b2 * factor
          farben(zaehler) = RGB(rot, gr�n, blau)
          zaehler = zaehler + 1
          If zaehler > anzahl Then
            farben(anzahl) = 0 'letzte Farbe immer Schwarz
            Exit Sub
          End If
        Next j
      Next i
    Loop
  End If
  farben(anzahl) = 0 'letzte Farbe immer Schwarz
End Sub

Public Function farb_modus&()
  Dim gdc&
  gdc = GetDeviceCaps(f_Param.hdc, 24)
  If gdc = 2 Then
    farb_modus = 2
  ElseIf gdc = 16 Then
    farb_modus = 2
  ElseIf gdc > 16 And gdc <= 256 Then
    farb_modus = 256
  Else
    farb_modus = 32768    'mindestens HiColor, vielleicht sogar TrueColor
  End If
End Function

