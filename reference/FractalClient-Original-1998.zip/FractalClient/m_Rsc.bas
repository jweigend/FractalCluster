Attribute VB_Name = "m_Rsc"
'
' File:       m_Rsc
' Beschr:     Hilfsfunktionen allgemein
' Author:     Martin Zapf
' Modified:   27.11.98 01:07
'
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Public Function MouseInObj(obj As Object, x As Single, y As Single) As Boolean
  If (x > Screen.ActiveForm.Left + obj.Left) And _
     (x < Screen.ActiveForm.Left + obj.Left + obj.width) And _
     (y > Screen.ActiveForm.Top + obj.Top) And _
     (y < Screen.ActiveForm.Top + obj.Top + obj.height) Then
    MouseInObj = False
  Else
    MouseInObj = True
  End If
End Function

Public Function MouseInArea(t As Single, l As Single, w As Single, h As Single, x As Single, y As Single) As Boolean
  If (x > Screen.ActiveForm.Left + l) And _
     (x < Screen.ActiveForm.Left + l + w) And _
     (y > Screen.ActiveForm.Top + t) And _
     (y < Screen.ActiveForm.Top + t + h) Then
    MouseInArea = False
  Else
    MouseInArea = True
  End If
End Function

Public Function GetLocalX(obj As Object, x As Single) As Single
' holt objektlokale Mouse-X Position
' gibt -1 zur�ck wenn Mousezeiger nicht in Objekt in X-richtung
'
  Dim tx As Single
  tx = x - Screen.ActiveForm.Left - obj.Left
  If tx < 0 Or tx > obj.width Then tx = -1
  GetLocalX = tx
End Function

Public Function MaxV(ByVal a As Variant, ByVal b As Variant) As Variant
  If a > b Then MaxV = a Else MaxV = b
End Function

Public Function MinV(ByVal a As Variant, ByVal b As Variant) As Variant
  If a < b Then MinV = a Else MinV = b
End Function

