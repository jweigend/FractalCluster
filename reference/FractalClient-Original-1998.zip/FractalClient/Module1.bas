Attribute VB_Name = "Module1"
'
' File:       Module1
' Author:     Martin Zapf
' Modified:   24.11.98 12:37
'

Declare Function SetPixelV Lib "gdi32" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal crColor As Long) As Long
Declare Function BitBlt Lib "gdi32" (ByVal dest_hdc As Long, ByVal dest_x As Long, ByVal dest_y As Long, ByVal dest_w As Long, ByVal dest_h As Long, ByVal src_hdc As Long, ByVal src_x As Long, ByVal src_y As Long, ByVal cpyopt As Long) As Long

Public Type t_Parameters
  real_min As Double
  real_max As Double
  imag_min As Double
  imag_max As Double
  block_w As Integer
  block_h As Integer
  max_iter As Integer
  max_threads As Integer
  picSize_x As Integer
  picSize_y As Integer
End Type


Public Param As t_Parameters
Public fm As f_main

Sub Main()
  ' Vorbelegung Parameter
  Call f_Parameter.SetParam(2, -2, 2, -2, 1000, 32, 20, 10, 640, 400)
  
  Set fm = New f_main
  Load fm
  fm.Show
  
End Sub
