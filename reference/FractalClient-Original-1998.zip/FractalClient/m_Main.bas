Attribute VB_Name = "m_Main"
'
' File:       m_Main
' Desc:       Hauptmodul
' Author:     Martin Zapf
' Modified:   30.11.98 2:45
'
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Declare Function SetPixelV Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal crColor As Long) As Long
Declare Function BitBlt Lib "gdi32" (ByVal dest_hdc As Long, ByVal dest_x As Long, ByVal dest_y As Long, ByVal dest_w As Long, ByVal dest_h As Long, ByVal src_hdc As Long, ByVal src_x As Long, ByVal src_y As Long, ByVal cpyopt As Long) As Long
Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public Declare Function GetDeviceCaps Lib "gdi32" (ByVal hdc As Long, ByVal nIndex As Long) As Long

Public Type t_Parameters
  real_min As Double
  real_max As Double
  imag_min As Double
  imag_max As Double
  distActive As Boolean
  block_w As Integer
  block_h As Integer
  max_iter As Long
  max_threads As Long
  picSize_x As Integer
  picSize_y As Integer
  colordepth As Integer
  colorchange As Integer
  coloroffset As Integer
  sizeprop As Integer
End Type

Public Param As t_Parameters
Public ParamMax As t_Parameters ' obere Grenzwerte
Public ParamMin As t_Parameters ' untere Grenzwerte

Public fm As f_main

Sub Main()
  ' Vorbelegung Parameter
  f_Param.SetParamStart
  
  Set fm = New f_main
  Load fm
  fm.Show
End Sub




