VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form f_main 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fest Einfach
   Caption         =   "FractalClient"
   ClientHeight    =   5730
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   6165
   Icon            =   "f_Main.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   PaletteMode     =   1  'ZReihenfolge
   ScaleHeight     =   5730
   ScaleWidth      =   6165
   StartUpPosition =   2  'Bildschirmmitte
   Begin VB.PictureBox FractalPic 
      AutoRedraw      =   -1  'True
      Height          =   5385
      Left            =   0
      ScaleHeight     =   355
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   407
      TabIndex        =   1
      Top             =   0
      Width           =   6165
      Begin VB.Shape sf_ZoomBox 
         BorderColor     =   &H00FFFFFF&
         BorderStyle     =   3  'Punkt
         Height          =   15
         Left            =   0
         Top             =   0
         Width           =   15
      End
   End
   Begin MSComctlLib.StatusBar sbStatusBar 
      Align           =   2  'Unten ausrichten
      Height          =   330
      Left            =   0
      TabIndex        =   0
      Top             =   5400
      Width           =   6165
      _ExtentX        =   10874
      _ExtentY        =   582
      Style           =   1
      ShowTips        =   0   'False
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   5689
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
         EndProperty
      EndProperty
   End
   Begin VB.Menu m_Datei 
      Caption         =   "&Datei"
      Begin VB.Menu m_Ende 
         Caption         =   "Client b&eenden"
         Shortcut        =   ^X
      End
   End
   Begin VB.Menu m_Fraktal 
      Caption         =   "&Fraktal"
      Begin VB.Menu m_Parameter 
         Caption         =   "&Parameter..."
         Shortcut        =   ^P
      End
      Begin VB.Menu Trennzeichen1 
         Caption         =   "-"
      End
      Begin VB.Menu m_ShowStatus 
         Caption         =   "zeige &Berechnung-Status"
         Shortcut        =   ^B
      End
      Begin VB.Menu m_ShowThreads 
         Caption         =   "aktiviere Thread-&Visualisierung"
         Shortcut        =   ^V
      End
      Begin VB.Menu Trennzeichen2 
         Caption         =   "-"
      End
      Begin VB.Menu m_StartCalculation 
         Caption         =   "&starte Berechnung"
         Shortcut        =   ^S
      End
      Begin VB.Menu m_StopCalc 
         Caption         =   "s&toppe Berechnung"
         Shortcut        =   ^T
      End
   End
   Begin VB.Menu m_Hilfe 
      Caption         =   "?"
      Begin VB.Menu m_About 
         Caption         =   "�ber &FractalClient..."
      End
   End
End
Attribute VB_Name = "f_main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
' File:       f_Main
' Desc:       Hauptobjekt f�r Menubefehle und Berechnung
' Author:     Martin Zapf
' Modified:   30.11.98 2:40
'

'--------------------------------------------------------------------
'
' DEFINITIONEN / DEKLARATIONEN
'
'--------------------------------------------------------------------
Option Explicit      ' Explizite Variablendeklaration erzwingen.

Dim fb_click As Integer         ' fractalBox mousedown
Dim ClickX As Integer
Dim ClickY As Integer
Dim Zoombox As Boolean        ' flag f�r Zoom

Private Type t_Main
  width As Long
  height As Long
End Type

Private Type t_BlockSize
  x As Integer
  y As Integer
  w As Integer
  h As Integer
End Type

Private Type t_Calc
  CalcStopped As Boolean
  CalcRunning As Boolean
  threadCount As Long
  ThreadsRunning As Long
  threadsInDraw As Long
  ThreadsReturned As Long
  Progress As Double
End Type

Private Type t_ThreadTable
  threadNr As Long      ' interne Nummer des Threads
  threadID As Long      ' Thread-ID die vom Server zur�ckgegeben wurde
  threadStarted As Boolean
  ThreadReturned As Boolean
  b_real_min As Double  ' real/imag Werte dieses Blocks (thread)
  b_real_max As Double
  b_imag_min As Double
  b_imag_max As Double
  start_x As Integer    ' start-koordinaten dieses Blocks ("pixels")
  start_y As Integer    '
  block_w As Integer    ' Gr��e des Blocks
  block_h As Integer    ' (width/height)
End Type


Private Calc As t_Calc
Private ThreadTable() As t_ThreadTable
Private MainProp As t_Main
Dim WithEvents server As FRACTALSERVERLib.MandelCalc
Attribute server.VB_VarHelpID = -1
Dim fStatus As f_Status
Dim param_show As Boolean
Dim farben&() 'Farbpalette


'--------------------------------------------------------------------
'
' FORM EVENTS
'
'--------------------------------------------------------------------

Private Sub Form_Load()
  'MainProp.width = Me.width
  'MainProp.height = Me.height
  ResizePic
  ' neues MandelServer-Objekt aufbauen
  Set server = New MandelCalc
  InitCalc
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Dim i As Integer
  StopCalc (False) ' stoppt Berechnung falls sie l�uft
  'close all sub forms
  For i = Forms.Count - 1 To 1 Step -1
    Unload Forms(i)
  Next
  Set server = Nothing
End Sub

Public Sub ResizePic()
' �ndert die Gr��e des Fensters nach den Bildgr��eParametern
  Me.width = Me.width + (Param.picSize_x * 15 - FractalPic.width)
  Me.height = Me.height + (Param.picSize_y * 15 - FractalPic.height)
  FractalPic.width = Param.picSize_x * 15
  FractalPic.height = Param.picSize_y * 15
  MainProp.width = Me.width
  MainProp.height = Me.height
  'Me.Left = Screen.width / 2 - Me.width / 2
  'Me.Top = Screen.height / 2 - Me.height / 2
End Sub

Private Sub FractalPic_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
  Zoombox = True                ' Rubber-Box zur Auswahl
  sf_ZoomBox.width = 0
  sf_ZoomBox.height = 0
  sf_ZoomBox.Visible = True
  sf_ZoomBox.DrawMode = 7             ' XOR-Modus
  ClickX = x
  ClickY = y
  FractalPic.MousePointer = 2         ' Fadenkreuz
End Sub

Private Sub FractalPic_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
  Dim len_x, len_y, startx, starty As Integer
  If Zoombox = False Then Exit Sub ' kein zoom
  
  If ClickX >= x Then
     len_x = ClickX - x
     startx = x
  Else
     len_x = x - ClickX
     startx = ClickX
  End If
  If ClickY >= y Then
     len_y = len_x * (FractalPic.height / FractalPic.width)
     starty = ClickY - len_y
  Else
     len_y = len_x * (FractalPic.height / FractalPic.width)
     starty = ClickY
  End If
  
  sf_ZoomBox.Left = startx
  sf_ZoomBox.Top = starty
  sf_ZoomBox.width = len_x
  sf_ZoomBox.height = len_y
  
End Sub

Private Sub FractalPic_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
   If Zoombox = False Then Exit Sub ' kein zoom
   Zoombox = False
   'If MsgBox("Soll dieser Bereich vergr�ssert werden?", vbYesNo, "Vergr�ssern") = vbNo Then
   '   sf_ZoomBox.Visible = False
   '   Exit Sub 'nicht zoomen
   'End If
   sf_ZoomBox.Visible = False
   If (sf_ZoomBox.width <= 1) Or (sf_ZoomBox.height <= 1) Then Exit Sub ' kein zoom
   If Calc.CalcRunning = True Then
      StopCalc (False) 'berechnung stoppen
      If Calc.CalcStopped = False Then Exit Sub 'nicht gestoppt
   End If
   If (Button = 2) Then
     zoom_out
   Else
     zoom_in
   End If
   m_StartCalculation_Click
End Sub

Private Sub m_About_Click()
  Dim fa As f_About
  Set fa = New f_About
  Load fa
  fa.Show
End Sub

'--------------------------------------------------------------------
'
' MENU ITEMS
'
'--------------------------------------------------------------------

Private Sub m_Ende_Click()
  StopCalc (False) ' stoppt Berechnung falls sie l�uft
  Unload Me
  End
End Sub

Private Sub m_Parameter_Click()
' zeigt Parameterdialog
  If Calc.CalcRunning = False Then
    Dim fp As f_Param
    Set fp = New f_Param
    Load fp
    fp.Show vbModal
    ResizePic
  Else
    If MsgBox("Berechnung mu� zuerst gestoppt werden!" + Chr$(13) + Chr$(10) + "Soll die Berechnung gestoppt werden?", vbYesNo, "Fractal-Info") = vbYes Then
      StopCalc (False)
      m_Parameter_Click
    End If
  End If
End Sub

Private Sub m_ShowStatus_Click()
  m_ShowStatus.Checked = Not m_ShowStatus.Checked
  If m_ShowStatus.Checked Then
    Set fStatus = New f_Status
    Load fStatus
    Call StatusMsg("---/---", Str$(Calc.ThreadsRunning), "---/---", Str$(Calc.ThreadsReturned), Str$(CInt(Calc.Progress)) + "%", CInt(Calc.Progress))
    fStatus.Show
  Else
    Unload fStatus
  End If
End Sub

Private Sub m_ShowThreads_Click()
  m_ShowThreads.Checked = Not m_ShowThreads.Checked
End Sub

Private Sub m_StopCalc_Click()
  StopCalc (True)
End Sub



'--------------------------------------------------------------------
'
' BERECHNUNG / SERVER
'
'--------------------------------------------------------------------

Private Sub InitCalc()
' init global calc vars
  With Calc
    .CalcRunning = False
    .CalcStopped = False
    .threadCount = 0
    .ThreadsRunning = 0
    .threadsInDraw = 0
    .ThreadsReturned = 0
    .Progress = 0
  End With
End Sub

Private Sub m_StartCalculation_Click()
  Dim threadID As Long
  Dim tc As Long
  
  If Calc.CalcRunning Then MsgBox "Berechnung l�uft bereits!", vbOKOnly, "Fractal-Info"
    
  InitCalc
  ' RGB-Farbtabelle anlegen
  Create_Color_Table Param.max_iter, farben
  
  Calc.CalcRunning = True
  Call StatusMsg("---/---", "---", "---", "---", "starte Berechnung...", 0)
  ResizePic
  FractalPic.Cls
  BuildThreadTable
  If Calc.CalcStopped = True Then Exit Sub
      
  sbStatusBar.SimpleText = "Berechnung l�uft..."
      
  tc = 0
  While (tc < Calc.threadCount) And (Calc.CalcStopped = False)
    If (Calc.ThreadsRunning >= Param.max_threads) Then Call WaitForFreeThread
    If (Calc.CalcStopped = True) Then Exit Sub 'sonst kann er beim beenden crashen
     
    tc = tc + 1
    server.maxit = Param.max_iter
       
    If ThreadTable(tc).threadStarted = False Then
      threadID = server.prepareCalc(ThreadTable(tc).b_real_min, ThreadTable(tc).b_imag_max, ThreadTable(tc).b_real_max, ThreadTable(tc).b_imag_min, ThreadTable(tc).block_w, ThreadTable(tc).block_h)
      ThreadTable(tc).threadID = threadID
      ThreadTable(tc).threadStarted = True
      Calc.ThreadsRunning = Calc.ThreadsRunning + 1
      ' visualisiere Thread
      If m_ShowThreads.Checked Then
        FractalPic.ScaleMode = 3
        FractalPic.Line (ThreadTable(tc).start_x, ThreadTable(tc).start_y)-(ThreadTable(tc).start_x + ThreadTable(tc).block_w, ThreadTable(tc).start_y + ThreadTable(tc).block_h), RGB(255, 0, 0), B
        FractalPic.ScaleMode = 1
      End If
      server.startCalc (threadID)
    
    
    If Not Calc.CalcStopped Then
      ' Fortschritt
      If Calc.threadCount > 0 Then
        Calc.Progress = Calc.Progress + 50 / Calc.threadCount
      Else
        Calc.Progress = 0
      End If
    
      ' update Status
      Call StatusMsg(Str$(tc) + "/" + Str$(threadID), Str$(Calc.ThreadsRunning), "$", Str$(Calc.ThreadsReturned), Str$(CInt(Calc.Progress)) + "%", CInt(Calc.Progress))
    End If
  End If
    
    DoEvents
  Wend
End Sub

Private Sub server_result(ByRef it() As Long, ByVal threadID As Long)
' empf�ngt Ergebnisse eines Threads vom Server durch Callback
  Dim n As Long
  If Calc.CalcStopped = True Then
    'Calc.CalcStoppedVerify = True
    Exit Sub
  End If
  
  Calc.ThreadsReturned = Calc.ThreadsReturned + 1
  ' zeichne Block
  n = FindThread(threadID)
  Call DrawFractalBlock(ThreadTable(n), it())
  Calc.ThreadsRunning = Calc.ThreadsRunning - 1
  
  If Not Calc.CalcStopped Then
    ' Fortschritt
    If Calc.threadCount > 0 Then
        Calc.Progress = Calc.Progress + 50 / Calc.threadCount
      Else
        Calc.Progress = 0
    End If
    
    ' update status
    Call StatusMsg("$", Str$(Calc.ThreadsRunning), Str$(n) + "/" + Str$(threadID), Str$(Calc.ThreadsReturned), Str$(CInt(Calc.Progress)) + "%", CInt(Calc.Progress))
  
    If CInt(Calc.Progress) = 100 Then
      Calc.CalcRunning = False
      sbStatusBar.SimpleText = "Berechnung abgeschlossen."
      Call StatusMsg("$", "$", "$", "$", "Berechnung abgeschlossen", -1)
    End If
  End If
End Sub

Private Sub StopCalc(ask As Boolean)
' stoppt alle laufenden Threads
  On Error Resume Next
  Dim c As Long
  
  If Calc.CalcRunning = False Then Exit Sub
  If Calc.CalcRunning = True Then
    If ask Then
      If MsgBox("Soll die Berechnung wirklich gestoppt werden?", vbYesNo, "Berechnung stoppen") = vbYes Then
        Calc.CalcStopped = True
      Else
        Exit Sub
      End If
    Else
      Calc.CalcStopped = True
    End If
  End If
  
  For c = 1 To Calc.threadCount
    If ThreadTable(c).threadStarted = True And ThreadTable(c).ThreadReturned = False And ThreadTable(c).threadID <> 0 Then
      server.StopCalc ThreadTable(c).threadID
      Calc.ThreadsRunning = Calc.ThreadsRunning - 1
      Call StatusMsg("$", Str$(Calc.ThreadsRunning), "$", "$", "stoppe Berechnung", 0)
    End If
  Next c
  
  Calc.CalcRunning = False
  sbStatusBar.SimpleText = "Berechnung wurde gestoppt."
  Call StatusMsg("---/---", "---/---", "---", "---", "Berechnung gestoppt", 0)
    
End Sub




'--------------------------------------------------------------------
'
' GRAFISCHE AUSGABE
'
'--------------------------------------------------------------------

Private Sub DrawFractalBlock(ByRef t As t_ThreadTable, ByVal value As Variant)
' zeichnet den zum aktuellen Thread geh�rigen Teil des Fractals
  Dim xcount, ycount, valcount As Long
  Dim res As Variant
  
  Calc.threadsInDraw = Calc.threadsInDraw + 1
  ' zeichne block
  xcount = t.start_x
  ycount = t.start_y
  
  For Each res In value   ' Iterate through each element.
    Call SetPixelV(FractalPic.hdc, xcount, ycount, farben(res))
    xcount = xcount + 1
    If xcount = t.start_x + t.block_w Then
      xcount = t.start_x
      ycount = ycount + 1
    End If
  Next
  FractalPic.Refresh
  Calc.threadsInDraw = Calc.threadsInDraw - 1
End Sub




'--------------------------------------------------------------------
'
' THREADS
'
'--------------------------------------------------------------------

Public Function ThreadsTotal()
' gibt Anzahl der Bl�cke zur�ck
  If Param.distActive Then  ' wenn Verteilung aktiv
    ThreadsTotal = GetBlocksInRow() * GetBlocksInCol()
  Else
    ThreadsTotal = 1
  End If
End Function

Private Sub WaitForFreeThread()
' wartet bis wieder ein Thread vom Server zur�ckgegebenen wurde
' und somit wieder einer "frei" ist
  While Calc.ThreadsRunning >= Param.max_threads
    If Calc.CalcStopped = True Then StopCalc (True)
    DoEvents
  Wend
End Sub

Private Sub BuildThreadTable()
' erstellt alle Informationen zu den einzelnen Threads

  Dim tt, c As Long
  'Dim sx, sy, bh, bw As Integer
  Dim Block As t_BlockSize
  
  tt = ThreadsTotal()     ' Anzahl der Threads bzw. Bl�cke
  ReDim ThreadTable(tt + 1)
  
  Call StatusMsg("$", "$", "$", "$", "Erstelle ThreadTable...", -1)
  ' erstelle Thread-Infos
  For c = 1 To tt
    ' Start-Koordinaten bestimmen
    Block = GetBlockSize(c, tt)
      
    ' ThreadID ist zu Beginn 0
    Call ThreadTable_Add(0, GetImagAt(Block.y), GetImagAt(Block.y + Block.h), GetRealAt(Block.x + Block.w), GetRealAt(Block.x), Block.x, Block.y, Block.w, Block.h)
  Next c
End Sub


Private Sub ThreadTable_Add(ByVal threadID As Long, ByVal imax As Double, ByVal imin As Double, ByVal rmax As Double, ByVal rmin As Double, ByVal startx As Integer, ByVal starty As Integer, ByVal width As Integer, ByVal height As Integer)
' setzt einen neuen Eintrag in die Thread-Tabelle
  Dim n As Integer
  Calc.threadCount = Calc.threadCount + 1
  n = Calc.threadCount
  ThreadTable(n).threadID = threadID
  ThreadTable(n).threadNr = n
  ThreadTable(n).b_imag_max = imax
  ThreadTable(n).b_imag_min = imin
  ThreadTable(n).b_real_max = rmax
  ThreadTable(n).b_real_min = rmin
  ThreadTable(n).start_x = startx
  ThreadTable(n).start_y = starty
  ThreadTable(n).block_w = width
  ThreadTable(n).block_h = height
End Sub

Private Function FindThread(ByVal tID As Long)
' findet anhand der threadID den passenden Thread in der Tabelle
  Dim c, p As Long
  
  For c = 1 To Calc.threadCount
    If (ThreadTable(c).threadID = tID) Then
      ThreadTable(c).ThreadReturned = True
      p = c
      Exit For
    End If
  Next c
  If p = 0 Then MsgBox "find: " + Str$(tID)
  FindThread = p
End Function


'--------------------------------------------------------------------
'
' VERTEILUNG
'
'--------------------------------------------------------------------

Private Function GetBlockSize(ByVal n As Integer, ByVal tt As Long) As t_BlockSize
' gibt die Blockgr��e des n-ten Threads zur�ck
  If Param.distActive Then  ' Verteilung ist aktiv
      GetBlockSize.x = GetStartX(n)
      GetBlockSize.y = GetStartY(n)
      
      ' Blockbreite und -h�he bestimmen
      ' wenn letzter Block in Reihe
      If (n Mod GetBlocksInRow()) = 0 Then
        GetBlockSize.w = GetRestX()
        ' wenn Blockbreite zu klein, fasse zwei Blocks zusammen
        If GetBlockSize.w < ParamMin.block_w Then GetBlockSize.w = GetBlockSize.w + Param.block_w
      Else
        GetBlockSize.w = Param.block_w
      End If
      
      ' wenn in letzter Reihe =>
      If (n > tt - GetBlocksInRow()) Then
        GetBlockSize.h = GetRestY()
        If GetBlockSize.h < ParamMin.block_h Then GetBlockSize.h = GetBlockSize.h + Param.block_h
      Else
        GetBlockSize.h = Param.block_h
      End If
    
    Else  ' keine Verteilung --> nur ein Thread
    
      GetBlockSize.x = 0
      GetBlockSize.y = 0
      GetBlockSize.w = Param.picSize_x
      GetBlockSize.h = Param.picSize_y
      
    End If

End Function

Private Function GetStartX(ByVal n As Long)
  Dim nrblocks, restx, p As Integer
  nrblocks = GetBlocksInRow
  ' rechnet aus, der wievielte Block dieser in x Richung ist (y-Richtung ist unrelevant)
  ' und multipliziert mit der Breite eines Blocks
  p = n Mod nrblocks
  If p = 0 Then p = nrblocks  ' Sonderfall: wenn n = nrblocks dann ergibt modulo 0!
  GetStartX = (p - 1) * Param.block_w
End Function

Private Function GetStartY(ByVal n As Long)
  Dim nrblocks As Integer
  Dim p As Integer
  nrblocks = GetBlocksInRow
  ' rechnet aus, in der wievielten Reihe der Block liegt
  ' und multipliziert mit der H�he eines Blocks
  p = Int(n / nrblocks)
  If (n Mod nrblocks) <> 0 Then p = p + 1
  GetStartY = (p - 1) * Param.block_h
End Function

Private Function GetBlocksInRow()
' Berechnet Anzahl blocks in einer Reihe
  Dim restx, f As Integer
  restx = GetRestX()
  ' fasst letzten zwei zusammen, falls der letzte zu klein ist
  If restx < ParamMin.block_w Then f = 0 Else f = 1
  GetBlocksInRow = ((Param.picSize_x - restx) / Param.block_w) + f
End Function

Private Function GetBlocksInCol()
' Berechnet Anzahl Blocks in einer Spalte
  Dim resty, f As Integer
  resty = GetRestY()
  ' fasst letzten zwei zusammen, falls der letzte zu klein ist
  If resty < ParamMin.block_h Then f = 0 Else f = 1
  GetBlocksInCol = ((Param.picSize_y - resty) / Param.block_h) + f
End Function

Private Function GetRestX()
  Dim restx As Integer
  restx = Param.picSize_x Mod Param.block_w
  If restx = 0 Then restx = Param.block_w
  GetRestX = restx
End Function

Private Function GetRestY()
  Dim resty As Integer
  resty = Param.picSize_y Mod Param.block_h
  If resty = 0 Then resty = Param.block_h
  GetRestY = resty
End Function

Private Function GetImagAt(ByVal y As Integer)
' berechnet den Imagin�rteil bei y (in Pixel)
  Dim tmp As Double
  tmp = Abs(Param.imag_max - Param.imag_min) / Param.picSize_y
  GetImagAt = Param.imag_max - (tmp * y)
End Function

Private Function GetRealAt(ByVal x As Integer)
' berechnet den Realteil bei x (in Pixel)
  Dim tmp As Double
  tmp = Abs(Param.real_max - Param.real_min) / Param.picSize_x
  GetRealAt = Param.real_min + (tmp * x)
End Function

Private Sub StatusMsg(ThreadNrStart As String, ThreadsRunning As String, ThreadNrReturn As String, ThreadsReturned As String, ProgMsg As String, ProgMet As Integer)
' �bertr�gt Daten in Status Form
  If m_ShowStatus.Checked Then
    If ProgMsg <> "$" Then fStatus.l_Progress.Caption = ProgMsg
    If (ProgMet <> -1) And (ProgMet <= 100) Then fStatus.ProgressBar.value = ProgMet
    If ThreadNrReturn <> "$" Then fStatus.el_ThreadNrReturn.Text = ThreadNrReturn
    If ThreadsReturned <> "$" Then fStatus.el_ThreadsReturned.Text = ThreadsReturned
    If ThreadsRunning <> "$" Then fStatus.el_ThreadsRunning.Text = ThreadsRunning
    If ThreadNrStart <> "$" Then fStatus.el_ThreadNrStart.Text = ThreadNrStart
  End If
End Sub

Private Sub zoom_in()
Dim temp_p As t_Parameters
   'neue Real/Imagnaerwerte berechnen
   temp_p = Param
   temp_p.real_min = Param.real_min + ((Param.real_max - Param.real_min) / FractalPic.ScaleWidth) * sf_ZoomBox.Left
   temp_p.real_max = Param.real_min + ((Param.real_max - Param.real_min) / FractalPic.ScaleWidth) * (sf_ZoomBox.Left + sf_ZoomBox.width)
   temp_p.imag_max = Param.imag_max - ((Param.imag_max - Param.imag_min) / FractalPic.ScaleHeight) * sf_ZoomBox.Top
   temp_p.imag_min = Param.imag_max - ((Param.imag_max - Param.imag_min) / FractalPic.ScaleHeight) * (sf_ZoomBox.Top + sf_ZoomBox.height)
   Param = temp_p
End Sub

Private Sub zoom_out()
Dim temp_p As t_Parameters
   temp_p = Param
   temp_p.real_min = Param.real_min - ((Param.real_max - Param.real_min) / sf_ZoomBox.width) * sf_ZoomBox.Left
   temp_p.real_max = Param.real_max + ((Param.real_max - Param.real_min) / sf_ZoomBox.width) * (FractalPic.ScaleWidth - sf_ZoomBox.Left - sf_ZoomBox.width)
   temp_p.imag_max = Param.imag_max + ((Param.imag_max - Param.imag_min) / sf_ZoomBox.height) * sf_ZoomBox.Top
   temp_p.imag_min = Param.imag_min - ((Param.imag_max - Param.imag_min) / sf_ZoomBox.height) * (FractalPic.ScaleHeight - sf_ZoomBox.Top - sf_ZoomBox.height)
   Param = temp_p
End Sub


