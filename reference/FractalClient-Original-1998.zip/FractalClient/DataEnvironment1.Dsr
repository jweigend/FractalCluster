VERSION 5.00
Begin {C0E45035-5775-11D0-B388-00A0C9055D8E} DataEnvironment1 
   ClientHeight    =   11340
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   13050
   _ExtentX        =   23019
   _ExtentY        =   20003
   FolderFlags     =   1
   TypeLibGuid     =   "{B518D5D3-8D3D-11D2-985A-004033A1348B}"
   TypeInfoGuid    =   "{B518D5D4-8D3D-11D2-985A-004033A1348B}"
   TypeInfoCookie  =   0
   Version         =   4
   NumConnections  =   1
   BeginProperty Connection1 
      ConnectionName  =   "Connection1"
      ConnDispId      =   1001
      SourceOfData    =   3
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   NumRecordsets   =   0
End
Attribute VB_Name = "DataEnvironment1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
