VERSION 5.00
Begin VB.Form f_Parameter 
   AutoRedraw      =   -1  'True
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Fraktalparameter"
   ClientHeight    =   3945
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8070
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3945
   ScaleWidth      =   8070
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame Frame_Calc 
      Caption         =   "Berechnung"
      Height          =   855
      Left            =   240
      TabIndex        =   24
      Top             =   2280
      Width           =   4335
      Begin VB.TextBox e_MaxIter 
         Height          =   285
         Left            =   1440
         TabIndex        =   25
         Text            =   "1000"
         Top             =   360
         Width           =   1335
      End
      Begin VB.Label Label8 
         Caption         =   "max. Iterationen:"
         Height          =   255
         Left            =   120
         TabIndex        =   26
         Top             =   360
         Width           =   1335
      End
   End
   Begin VB.CommandButton b_Cancel 
      Caption         =   "Abbruch"
      Height          =   375
      Left            =   6000
      TabIndex        =   23
      Top             =   3360
      Width           =   1815
   End
   Begin VB.CommandButton b_Ok 
      Caption         =   "Ok"
      Height          =   375
      Left            =   4080
      TabIndex        =   22
      Top             =   3360
      Width           =   1815
   End
   Begin VB.Frame Frame_Thread 
      Caption         =   "Verteilung (Threads)"
      Height          =   1575
      Left            =   4800
      TabIndex        =   14
      Top             =   1560
      Width           =   3015
      Begin VB.TextBox e_NrOfThreads 
         Height          =   285
         Left            =   2280
         Locked          =   -1  'True
         TabIndex        =   21
         Text            =   "1"
         ToolTipText     =   "Anzahl Bl�cke (bzw. Threads), in die die Bilderechnung unterteilt wird."
         Top             =   1080
         Width           =   615
      End
      Begin VB.TextBox e_MaxThreads 
         Height          =   285
         Left            =   1200
         TabIndex        =   19
         Text            =   "1"
         Top             =   1080
         Width           =   975
      End
      Begin VB.TextBox e_BlockH 
         Height          =   285
         Left            =   1200
         TabIndex        =   18
         Text            =   "200"
         Top             =   720
         Width           =   975
      End
      Begin VB.TextBox e_BlockW 
         Height          =   285
         Left            =   1200
         TabIndex        =   17
         Text            =   "320"
         Top             =   360
         Width           =   975
      End
      Begin VB.Label Label7 
         Caption         =   "max. Threads:"
         Height          =   255
         Left            =   120
         TabIndex        =   20
         ToolTipText     =   "Maximale Anzahl von Threads, die gleichzeitig gestartet werden."
         Top             =   1080
         Width           =   1335
      End
      Begin VB.Label Label6 
         Caption         =   "Blockh�he:"
         Height          =   255
         Left            =   120
         TabIndex        =   16
         Top             =   720
         Width           =   975
      End
      Begin VB.Label Label5 
         Caption         =   "Blockbreite:"
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   360
         Width           =   975
      End
   End
   Begin VB.Frame Frame_Bild 
      Caption         =   "Bildgr��e"
      Height          =   1215
      Left            =   4800
      TabIndex        =   9
      Top             =   240
      Width           =   3015
      Begin VB.TextBox e_PicHeight 
         Height          =   285
         Left            =   1200
         TabIndex        =   13
         Text            =   "200"
         Top             =   720
         Width           =   975
      End
      Begin VB.TextBox e_PicWidth 
         Height          =   285
         Left            =   1200
         TabIndex        =   12
         Text            =   "320"
         Top             =   360
         Width           =   975
      End
      Begin VB.Label Label4 
         Caption         =   "H�he:"
         Height          =   255
         Left            =   120
         TabIndex        =   11
         Top             =   720
         Width           =   1095
      End
      Begin VB.Label Label3 
         Caption         =   "Breite:"
         Height          =   255
         Left            =   120
         TabIndex        =   10
         Top             =   360
         Width           =   1095
      End
   End
   Begin VB.Frame Frame_RI 
      Caption         =   "Real / Imagin�rteil"
      Height          =   1935
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   4335
      Begin VB.TextBox e_real_min 
         Height          =   285
         Left            =   1200
         TabIndex        =   4
         Text            =   "-2"
         Top             =   360
         Width           =   2895
      End
      Begin VB.TextBox e_imag_min 
         Height          =   285
         Left            =   1200
         TabIndex        =   3
         Text            =   "-2"
         Top             =   1080
         Width           =   2895
      End
      Begin VB.TextBox e_imag_max 
         Height          =   285
         Left            =   1200
         TabIndex        =   2
         Text            =   "2"
         Top             =   1440
         Width           =   2895
      End
      Begin VB.TextBox e_real_max 
         Height          =   285
         Left            =   1200
         TabIndex        =   1
         Text            =   "2"
         Top             =   720
         Width           =   2895
      End
      Begin VB.Label Label1 
         Caption         =   "Real min:"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   8
         Top             =   360
         Width           =   975
      End
      Begin VB.Label Label2 
         Caption         =   "Imagin�r min:"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   7
         Top             =   1080
         Width           =   975
      End
      Begin VB.Label Label1 
         Caption         =   "Real max:"
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   6
         Top             =   720
         Width           =   975
      End
      Begin VB.Label Label2 
         Caption         =   "Imagin�r max:"
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   5
         Top             =   1440
         Width           =   975
      End
   End
End
Attribute VB_Name = "f_Parameter"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
' File:       f_Parameter
' Author:     Martin Zapf
' Modified:   23.11.98 20:30
'

Private Sub Form_Load()
' trage Parameter in Form ein
  e_BlockW.Text = Param.block_w
  e_BlockH.Text = Param.block_h
  e_imag_max.Text = Param.imag_max
  e_imag_min.Text = Param.imag_min
  e_real_max.Text = Param.real_max
  e_real_min.Text = Param.real_min
  e_MaxThreads.Text = Param.max_threads
  e_MaxIter.Text = Param.max_iter
  e_PicWidth.Text = Param.picSize_x
  e_PicHeight.Text = Param.picSize_y
End Sub

Private Sub b_Ok_Click()
' setze Parameter
  Call SetParam(e_real_max.Text, e_real_min.Text, e_imag_max.Text, e_imag_min.Text, e_MaxIter.Text, e_BlockW.Text, e_BlockH.Text, e_MaxThreads.Text, e_PicWidth.Text, e_PicHeight.Text)
  Hide
End Sub

Private Sub b_Cancel_Click()
  Hide
End Sub

Public Sub SetParam(ByVal rmax As Double, ByVal rmin As Double, ByVal imax As Double, ByVal imin As Double, ByVal maxIter As Integer, ByVal blockw As Integer, ByVal blockh As Integer, ByVal maxThreads As Long, ByVal psx As Integer, ByVal psy As Integer)
' setzt Parameter
  Param.block_w = blockw
  Param.block_h = blockh
  Param.imag_max = imax
  Param.imag_min = imin
  Param.real_max = rmax
  Param.real_min = rmin
  Param.max_threads = maxThreads
  Param.max_iter = maxIter
  Param.picSize_x = psx
  Param.picSize_y = psy
End Sub
