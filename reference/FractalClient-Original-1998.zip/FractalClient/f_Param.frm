VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form f_Param 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Parameter"
   ClientHeight    =   5835
   ClientLeft      =   2565
   ClientTop       =   1500
   ClientWidth     =   7695
   Icon            =   "f_Param.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5835
   ScaleWidth      =   7695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picOptions 
      BorderStyle     =   0  'None
      Height          =   4710
      Index           =   2
      Left            =   -20000
      ScaleHeight     =   4710
      ScaleWidth      =   7095
      TabIndex        =   24
      TabStop         =   0   'False
      Top             =   510
      Width           =   7100
      Begin VB.Frame FramePicS 
         Height          =   1365
         Left            =   180
         TabIndex        =   32
         Top             =   360
         Width           =   2625
         Begin VB.CheckBox chk_sizeprop 
            Caption         =   "Verzerrung zulassen"
            Height          =   225
            Left            =   240
            TabIndex        =   21
            Top             =   870
            Width           =   1875
         End
         Begin VB.TextBox e_PicWidth 
            Height          =   285
            Left            =   240
            MaxLength       =   4
            TabIndex        =   19
            Text            =   "320"
            Top             =   510
            Width           =   975
         End
         Begin VB.TextBox e_PicHeight 
            Enabled         =   0   'False
            Height          =   285
            Left            =   1410
            MaxLength       =   4
            TabIndex        =   20
            Text            =   "320"
            Top             =   510
            Width           =   975
         End
         Begin VB.Label Label5 
            Caption         =   "x"
            Height          =   255
            Left            =   1260
            TabIndex        =   35
            Top             =   540
            Width           =   195
         End
         Begin VB.Label Label3 
            Caption         =   "Breite:"
            Height          =   255
            Left            =   240
            TabIndex        =   34
            Top             =   270
            Width           =   525
         End
         Begin VB.Label Label4 
            Caption         =   "H�he:"
            Height          =   255
            Left            =   1410
            TabIndex        =   33
            Top             =   270
            Width           =   525
         End
      End
   End
   Begin VB.PictureBox picOptions 
      BorderStyle     =   0  'None
      Height          =   4740
      Index           =   3
      Left            =   -20000
      ScaleHeight     =   4740
      ScaleWidth      =   7275
      TabIndex        =   47
      TabStop         =   0   'False
      Top             =   480
      Width           =   7275
      Begin VB.TextBox e_ColChange 
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "0"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1031
            SubFormatType   =   1
         EndProperty
         Height          =   285
         Left            =   5760
         TabIndex        =   56
         Text            =   "Text2"
         Top             =   720
         Width           =   615
      End
      Begin VB.TextBox e_ColOffset 
         BeginProperty DataFormat 
            Type            =   1
            Format          =   "0"
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1031
            SubFormatType   =   1
         EndProperty
         Height          =   285
         Left            =   5760
         TabIndex        =   55
         Text            =   "Text1"
         Top             =   360
         Width           =   615
      End
      Begin VB.Frame Frame1 
         Caption         =   "Farbtiefe"
         Height          =   1935
         Left            =   120
         TabIndex        =   48
         Top             =   240
         Width           =   3135
         Begin VB.OptionButton ColorOption1 
            Caption         =   "2 Farben (1 Bit)"
            Height          =   255
            Left            =   240
            TabIndex        =   52
            Top             =   360
            Width           =   2535
         End
         Begin VB.OptionButton ColorOption4 
            Caption         =   "16 Farben (4 Bit)"
            Height          =   375
            Left            =   240
            TabIndex        =   51
            Top             =   615
            Width           =   2535
         End
         Begin VB.OptionButton ColorOption8 
            Caption         =   "256 Farben (8 Bit)"
            Height          =   375
            Left            =   240
            TabIndex        =   50
            Top             =   990
            Width           =   2535
         End
         Begin VB.OptionButton ColorOption16 
            Caption         =   "64K/16,7M Farben (16/24 Bit)"
            Height          =   375
            Left            =   240
            TabIndex        =   49
            Top             =   1365
            Width           =   2535
         End
      End
      Begin VB.Label Label17 
         Caption         =   "Farb�nderung (5...):"
         Height          =   255
         Left            =   3600
         TabIndex        =   54
         Top             =   720
         Width           =   1815
      End
      Begin VB.Label Label6 
         Caption         =   "Farboffset (0-11):"
         Height          =   255
         Left            =   3600
         TabIndex        =   53
         Top             =   360
         Width           =   1695
      End
   End
   Begin VB.PictureBox picOptions 
      BorderStyle     =   0  'None
      Height          =   4740
      Index           =   1
      Left            =   -20000
      ScaleHeight     =   4740
      ScaleWidth      =   7275
      TabIndex        =   23
      TabStop         =   0   'False
      Top             =   480
      Width           =   7275
      Begin VB.TextBox el_BlockSize 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   1830
         Locked          =   -1  'True
         TabIndex        =   13
         Top             =   3420
         Width           =   1185
      End
      Begin VB.TextBox el_PicSize 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   1830
         Locked          =   -1  'True
         TabIndex        =   14
         Top             =   3060
         Width           =   1185
      End
      Begin VB.CheckBox chk_EnableDist 
         Caption         =   "Verteilung aktivieren"
         Height          =   255
         Left            =   270
         TabIndex        =   15
         Top             =   240
         Width           =   2505
      End
      Begin VB.Frame FrameThread 
         Caption         =   "Multithreading"
         Height          =   1875
         Left            =   3570
         TabIndex        =   40
         Top             =   630
         Width           =   2985
         Begin VB.TextBox e_MaxThreads 
            Height          =   285
            Left            =   480
            MaxLength       =   6
            TabIndex        =   18
            Text            =   "1"
            Top             =   870
            Width           =   2085
         End
         Begin VB.Label Label7 
            Caption         =   "maximale Anzahl gleichzeitig laufender Threads:"
            Height          =   495
            Left            =   480
            TabIndex        =   41
            Top             =   450
            Width           =   2055
         End
      End
      Begin VB.TextBox el_NrOfThreads 
         BackColor       =   &H8000000A&
         Height          =   285
         Left            =   4470
         Locked          =   -1  'True
         TabIndex        =   10
         Text            =   "1"
         Top             =   3420
         Width           =   1185
      End
      Begin VB.Frame FrameDistrib 
         Caption         =   "Blockgr��e"
         Height          =   1875
         Left            =   270
         TabIndex        =   36
         Top             =   630
         Width           =   2985
         Begin VB.TextBox e_BlockW 
            Height          =   285
            Left            =   420
            MaxLength       =   4
            TabIndex        =   16
            Text            =   "30"
            Top             =   870
            Width           =   975
         End
         Begin VB.TextBox e_BlockH 
            Height          =   285
            Left            =   1590
            MaxLength       =   4
            TabIndex        =   17
            Text            =   "30"
            Top             =   870
            Width           =   975
         End
         Begin VB.Label Label11 
            Caption         =   "x"
            Height          =   255
            Left            =   1440
            TabIndex        =   39
            Top             =   900
            Width           =   165
         End
         Begin VB.Label Label10 
            Caption         =   "Blockbreite:"
            Height          =   255
            Left            =   420
            TabIndex        =   38
            Top             =   630
            Width           =   975
         End
         Begin VB.Label Label9 
            Caption         =   "Blockh�he:"
            Height          =   255
            Left            =   1590
            TabIndex        =   37
            Top             =   630
            Width           =   975
         End
      End
      Begin VB.Label Label14 
         Caption         =   "Anzahl Bl�cke bzw. Threads:"
         Height          =   405
         Left            =   4440
         TabIndex        =   44
         Top             =   3000
         Width           =   1305
      End
      Begin VB.Shape Shape2 
         BorderColor     =   &H80000010&
         Height          =   945
         Left            =   4170
         Top             =   2910
         Width           =   1725
      End
      Begin VB.Line Line5 
         BorderColor     =   &H80000010&
         X1              =   3240
         X2              =   4170
         Y1              =   3390
         Y2              =   3390
      End
      Begin VB.Label Label13 
         Caption         =   "Blockgr��e:"
         Height          =   225
         Left            =   870
         TabIndex        =   43
         Top             =   3450
         Width           =   885
      End
      Begin VB.Label Label12 
         Caption         =   "Bildgr��e:"
         Height          =   225
         Left            =   870
         TabIndex        =   42
         Top             =   3090
         Width           =   975
      End
      Begin VB.Shape Shape1 
         BorderColor     =   &H80000010&
         Height          =   945
         Left            =   780
         Top             =   2910
         Width           =   2475
      End
      Begin VB.Line Line4 
         BorderColor     =   &H80000010&
         X1              =   480
         X2              =   780
         Y1              =   3390
         Y2              =   3390
      End
      Begin VB.Line Line3 
         BorderColor     =   &H80000010&
         X1              =   480
         X2              =   480
         Y1              =   2520
         Y2              =   3390
      End
   End
   Begin VB.PictureBox picOptions 
      BorderStyle     =   0  'None
      Height          =   4725
      Index           =   0
      Left            =   240
      ScaleHeight     =   4725
      ScaleWidth      =   7275
      TabIndex        =   22
      TabStop         =   0   'False
      Top             =   480
      Width           =   7275
      Begin VB.TextBox e_MaxIter 
         Height          =   285
         Left            =   5430
         MaxLength       =   9
         TabIndex        =   12
         Text            =   "20"
         Top             =   4020
         Width           =   1635
      End
      Begin VB.Frame Frame_RI 
         Caption         =   "Real / Imagin�r - Startwerte"
         Height          =   3795
         Left            =   240
         TabIndex        =   25
         Top             =   120
         Width           =   6855
         Begin VB.TextBox el_Y 
            BackColor       =   &H8000000A&
            Height          =   285
            Left            =   4980
            Locked          =   -1  'True
            TabIndex        =   11
            TabStop         =   0   'False
            Top             =   3300
            Width           =   1635
         End
         Begin VB.TextBox el_X 
            BackColor       =   &H8000000A&
            Height          =   285
            Left            =   4980
            Locked          =   -1  'True
            TabIndex        =   9
            TabStop         =   0   'False
            Top             =   3000
            Width           =   1635
         End
         Begin VB.PictureBox FractalBox 
            Appearance      =   0  'Flat
            BackColor       =   &H00FF0000&
            BorderStyle     =   0  'None
            ForeColor       =   &H80000008&
            Height          =   2295
            Left            =   1230
            MousePointer    =   2  'Cross
            Picture         =   "f_Param.frx":0442
            ScaleHeight     =   2310.403
            ScaleMode       =   0  'User
            ScaleWidth      =   2310.403
            TabIndex        =   30
            Top             =   780
            Width           =   2295
            Begin VB.Shape sf_DragBox 
               BorderColor     =   &H00FFFFFF&
               BorderStyle     =   3  'Dot
               Height          =   2280
               Left            =   0
               Top             =   0
               Width           =   2280
            End
            Begin VB.Line Line2 
               BorderColor     =   &H0080FFFF&
               X1              =   1026.846
               X2              =   1298.658
               Y1              =   1147.651
               Y2              =   1147.651
            End
            Begin VB.Line Line1 
               BorderColor     =   &H0080FFFF&
               X1              =   1147.651
               X2              =   1147.651
               Y1              =   1026.846
               Y2              =   1298.658
            End
         End
         Begin VB.TextBox e_real_max 
            BeginProperty DataFormat 
               Type            =   1
               Format          =   "0,00000"
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1031
               SubFormatType   =   1
            EndProperty
            Height          =   285
            Left            =   3570
            MaxLength       =   20
            TabIndex        =   6
            Text            =   "2"
            Top             =   1830
            Width           =   1035
         End
         Begin VB.TextBox e_imag_max 
            BeginProperty DataFormat 
               Type            =   1
               Format          =   "0,00000"
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1031
               SubFormatType   =   1
            EndProperty
            Height          =   285
            Left            =   1890
            MaxLength       =   20
            TabIndex        =   4
            Text            =   "2"
            Top             =   480
            Width           =   1035
         End
         Begin VB.TextBox e_imag_min 
            BeginProperty DataFormat 
               Type            =   1
               Format          =   "0,00000"
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1031
               SubFormatType   =   1
            EndProperty
            Height          =   285
            Left            =   1890
            MaxLength       =   20
            TabIndex        =   7
            Text            =   "-2"
            Top             =   3090
            Width           =   1035
         End
         Begin VB.TextBox e_real_min 
            BeginProperty DataFormat 
               Type            =   1
               Format          =   "0,00000"
               HaveTrueFalseNull=   0
               FirstDayOfWeek  =   0
               FirstWeekOfYear =   0
               LCID            =   1031
               SubFormatType   =   1
            EndProperty
            Height          =   285
            Left            =   150
            MaxLength       =   20
            TabIndex        =   5
            Text            =   "-2"
            Top             =   1800
            Width           =   1035
         End
         Begin VB.Label RI_Hinweis 
            Caption         =   "Hinweis: Gebe die Startwerte manuell ein oder markiere einen Bereich im Fraktal mit der Mouse."
            Height          =   885
            Left            =   4620
            TabIndex        =   8
            Top             =   270
            Width           =   2055
         End
         Begin VB.Line Line6 
            BorderColor     =   &H80000010&
            X1              =   3540
            X2              =   4170
            Y1              =   2910
            Y2              =   2910
         End
         Begin VB.Shape Shape3 
            BorderColor     =   &H80000010&
            Height          =   795
            Left            =   4170
            Top             =   2910
            Width           =   2595
         End
         Begin VB.Label Label16 
            Caption         =   "Imagin�r:"
            Height          =   225
            Left            =   4290
            TabIndex        =   46
            Top             =   3330
            Width           =   735
         End
         Begin VB.Label Label15 
            Caption         =   "Real:"
            Height          =   225
            Left            =   4560
            TabIndex        =   45
            Top             =   3030
            Width           =   465
         End
         Begin VB.Label Label2 
            Caption         =   "Imagin�r max:"
            Height          =   255
            Index           =   1
            Left            =   1890
            TabIndex        =   29
            Top             =   270
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "Real max:"
            Height          =   255
            Index           =   1
            Left            =   3570
            TabIndex        =   28
            Top             =   1590
            Width           =   975
         End
         Begin VB.Label Label2 
            Caption         =   "Imagin�r min:"
            Height          =   255
            Index           =   0
            Left            =   1890
            TabIndex        =   27
            Top             =   3390
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "Real min:"
            Height          =   255
            Index           =   0
            Left            =   150
            TabIndex        =   26
            Top             =   1590
            Width           =   975
         End
      End
      Begin VB.Label Label8 
         Caption         =   "maximale Anzahl Iterationen:"
         Height          =   255
         Left            =   3300
         TabIndex        =   31
         Top             =   4050
         Width           =   2085
      End
   End
   Begin VB.CommandButton cmdApply 
      Caption         =   "�bernehmen"
      Height          =   375
      Left            =   1800
      TabIndex        =   2
      Top             =   5370
      Width           =   1575
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Abbrechen"
      Height          =   375
      Left            =   5970
      TabIndex        =   3
      Top             =   5370
      Width           =   1575
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   5370
      Width           =   1575
   End
   Begin MSComctlLib.TabStrip tbsParam 
      Height          =   5175
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   7425
      _ExtentX        =   13097
      _ExtentY        =   9128
      MultiRow        =   -1  'True
      _Version        =   393216
      BeginProperty Tabs {1EFB6598-857C-11D1-B16A-00C0F0283628} 
         NumTabs         =   4
         BeginProperty Tab1 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Berechnung"
            Key             =   "calculation"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab2 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Verteilung"
            Key             =   "distrib"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab3 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Bildgr��e"
            Key             =   "picsize"
            ImageVarType    =   2
         EndProperty
         BeginProperty Tab4 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Farben"
            Key             =   "colors"
            ImageVarType    =   2
         EndProperty
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "f_Param"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'
' File:       f_Param
' Desc:       Parameter Form
' Author:     Martin Zapf
' Modified:   30.11.98 02:45
'

Option Explicit      ' Explizite Variablendeklaration erzwingen.
Dim fb_click As Integer         ' fractalBox mousedown


'--------------------------------------------------------------------
'
' COMMAND BUTTONS
'
'--------------------------------------------------------------------

Private Sub cmdApply_Click()
  Param = GetParameters
End Sub

Private Sub cmdCancel_Click()
  Unload Me
End Sub

Private Sub cmdOK_Click()
  Param = GetParameters
  Unload Me
End Sub



Private Sub e_ColChange_GotFocus()
  e_ColChange.SelStart = 0
  e_ColChange.SelLength = Len(e_ColChange.Text)
End Sub

Private Sub e_ColOffset_GotFocus()
  e_ColOffset.SelStart = 0
  e_ColOffset.SelLength = Len(e_ColOffset.Text)
End Sub

'--------------------------------------------------------------------
' FORM EVENTS
'--------------------------------------------------------------------

Private Sub Form_Load()
    SetColordepth   ' setzen der m�glichen Farbtiefen
    'Formular zentrieren
    SetParamMinMax  ' setze Grenzwerte
    SetParameters   ' lese Param in Form ein
    UpdateDistribTab
    UpdatePicSize
    UpdateDragBox
    fb_click = False
End Sub

Private Sub Label21_Click()

End Sub

Private Sub tbsParam_Click()
' wechselt Reiter in Kartei
' Steuerelemente der ausgew�hlten Registerkarte anzeigen und aktivieren
' und alle anderen ausblenden und deaktivieren
  Dim i As Integer
  For i = 0 To tbsParam.Tabs.Count - 1
    If i = tbsParam.SelectedItem.Index - 1 Then
      picOptions(i).Left = 210
      picOptions(i).Enabled = True
    Else
      picOptions(i).Left = -20000
      picOptions(i).Enabled = False
    End If
  Next
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Dim i As Integer
    'STRG+TAB-Zugriffsnummer, um zur n�chsten Registerkarte zu wechseln
    If Shift = vbCtrlMask And KeyCode = vbKeyTab Then
        i = tbsParam.SelectedItem.Index
        If i = tbsParam.Tabs.Count Then
            'Letzte Registerkarte, also wieder mit der ersten beginnen
            Set tbsParam.SelectedItem = tbsParam.Tabs(1)
        Else
            'Registerkarte hochz�hlen
            Set tbsParam.SelectedItem = tbsParam.Tabs(i + 1)
        End If
    End If
End Sub




'--------------------------------------------------------------------
'
' PARAMETER BERECHNUNG: FRACTALBOX
'
'--------------------------------------------------------------------

Private Sub FractalBox_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If fb_click = True Then Exit Sub
  e_real_min.Text = el_X.Text
  e_imag_max.Text = el_Y.Text
  sf_DragBox.Top = Y
  sf_DragBox.Left = X
  sf_DragBox.width = 1
  sf_DragBox.height = 1
  fb_click = True
End Sub

Private Sub FractalBox_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If MouseInObj(FractalBox, X, Y) Then
    el_X.Text = (GetSign(X, Y) * ((4 / FractalBox.width) * X)) - 2
    el_Y.Text = -1 * ((GetSign(X, Y) * ((4 / FractalBox.height) * Y)) - 2)
    If el_X.Text > 2# Then el_X.Text = 2    ' wenn �ber rechten Rand hinaus
    If el_Y.Text < -2# Then el_Y.Text = -2  ' wenn �ber unteren Rand hinaus
    
    If fb_click Then
      If (X - sf_DragBox.Left) > 0 Then sf_DragBox.width = X - sf_DragBox.Left Else sf_DragBox.width = 1
      If (Y - sf_DragBox.Top) > 0 Then sf_DragBox.height = Y - sf_DragBox.Top Else sf_DragBox.height = 1
      If (sf_DragBox.Left + sf_DragBox.width > FractalBox.width) Then
        sf_DragBox.width = FractalBox.width - sf_DragBox.Left
      End If
      If (sf_DragBox.Top + sf_DragBox.height > FractalBox.height) Then
        sf_DragBox.height = FractalBox.height - sf_DragBox.Top
      End If
      e_imag_min.Text = el_Y.Text
      e_real_max.Text = el_X.Text
    End If
  End If
End Sub

Private Sub FractalBox_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  If fb_click = False Then Exit Sub
  e_real_max.Text = el_X.Text
  e_imag_min.Text = el_Y.Text
  
  If (CDbl(e_real_min.Text) >= CDbl(e_real_max.Text)) Or (CDbl(e_imag_min.Text) >= CDbl(e_imag_max.Text)) Then
    e_real_max.Text = ParamMax.real_max
    e_real_min.Text = ParamMin.real_min
    e_imag_max.Text = ParamMax.imag_max
    e_imag_min.Text = ParamMin.imag_min
    sf_DragBox.Top = 0
    sf_DragBox.Left = 0
    sf_DragBox.width = FractalBox.width
    sf_DragBox.height = FractalBox.height
  End If
  
  sf_DragBox.Refresh
  fb_click = False
  UpdatePicSize
End Sub

Private Function GetSign(ByVal X As Single, ByVal Y As Single) As Integer
' Hilfsfunktion zu FractalBox
' gibt entsprechendes Vorzeichen zur�ck von dem Quadranten in dem sich die
' Mouse gerade befindet
  ' links oben
  If MouseInArea(FractalBox.Top, FractalBox.Left, FractalBox.width / 2, FractalBox.height / 2, X, Y) Then GetSign = -1
  ' rechts oben
  If MouseInArea(FractalBox.Top, FractalBox.Left + FractalBox.width / 2, FractalBox.width / 2, FractalBox.height / 2, X, Y) Then GetSign = 1
  ' links unten
  If MouseInArea(FractalBox.Top + FractalBox.height / 2, FractalBox.Left, FractalBox.width / 2, FractalBox.height / 2, X, Y) Then GetSign = -1
  ' rechts unten
  If MouseInArea(FractalBox.Top + FractalBox.height / 2, FractalBox.Left + FractalBox.width / 2, FractalBox.width / 2, FractalBox.height / 2, X, Y) Then GetSign = 1
End Function

Private Sub UpdateDragBox()
' passt Gr��e der DragBox in Fractalbox an die manuell eingegebenen
' Werte an
  Dim t As Double
  t = e_imag_max.Text
  If (t >= 0) Then sf_DragBox.Top = (FractalBox.height / 2) * Abs((2# - t) / 2#)
  If (t < 0) Then sf_DragBox.Top = (FractalBox.height / 2) + (FractalBox.height / 2) * ((-1 * t) / 2#)
  
  t = e_imag_max.Text - e_imag_min.Text
  sf_DragBox.height = 1 + FractalBox.height * Abs(t / 4#)
  
  t = e_real_min.Text
  If (t >= 0) Then sf_DragBox.Left = (FractalBox.width / 2) + (FractalBox.width / 2) * (t / 2#)
  If (t < 0) Then sf_DragBox.Left = (FractalBox.height / 2) * Abs((2# - Abs(t)) / 2#)
  
  t = e_real_max.Text - e_real_min.Text
  sf_DragBox.width = 1 + FractalBox.width * Abs(t / 4#)
  UpdatePicSize
End Sub


'--------------------------------------------------------------------
'
' PARAMETER BERECHNUNG
'
'--------------------------------------------------------------------

Private Sub e_imag_max_LostFocus()
  'On Error Resume Next
  If e_imag_max.Text = "" Then e_imag_max.Text = ParamMax.imag_max
  If CDbl(e_imag_max.Text) < ParamMin.imag_max Then e_imag_max.Text = ParamMin.imag_max
  If CDbl(e_imag_max.Text) > ParamMax.imag_max Then e_imag_max.Text = ParamMax.imag_max
  UpdateDragBox
End Sub
Private Sub e_imag_min_LostFocus()
  'On Error Resume Next
  If e_imag_min.Text = "" Then e_imag_min.Text = ParamMin.imag_min
  If CDbl(e_imag_min.Text) < ParamMin.imag_min Then e_imag_min.Text = ParamMin.imag_min
  If CDbl(e_imag_min.Text) > ParamMax.imag_min Then e_imag_min.Text = ParamMax.imag_min
  UpdateDragBox
End Sub
Private Sub e_real_max_LostFocus()
  'On Error Resume Next
  If e_real_max.Text = "" Then e_real_max.Text = ParamMax.real_max
  If CDbl(e_real_max.Text) < ParamMin.real_max Then e_real_max.Text = ParamMin.real_max
  If CDbl(e_real_max.Text) > ParamMax.real_max Then e_real_max.Text = ParamMax.real_max
  UpdateDragBox
End Sub
Private Sub e_real_min_LostFocus()
  'On Error Resume Next
  If e_real_min.Text = "" Then e_real_min.Text = ParamMin.real_min
  If CDbl(e_real_min.Text) < ParamMin.real_min Then e_real_min.Text = ParamMin.real_min
  If CDbl(e_real_min.Text) > ParamMax.real_min Then e_real_min.Text = ParamMax.real_min
  UpdateDragBox
End Sub
Private Sub e_MaxIter_LostFocus()
  'On Error Resume Next
  If Val(e_MaxIter.Text) < ParamMin.max_iter Then e_MaxIter.Text = ParamMin.max_iter
  If Val(e_MaxIter.Text) > ParamMax.max_iter Then e_MaxIter.Text = ParamMax.max_iter
End Sub



'--------------------------------------------------------------------
'
' PARAMETER VERTEILUNG
'
'--------------------------------------------------------------------

Private Sub e_BlockH_LostFocus()
  'On Error Resume Next
  If Val(e_BlockH.Text) <= ParamMin.block_h Then e_BlockH.Text = ParamMin.block_h
  If Val(e_BlockH.Text) > ParamMax.block_h Then e_BlockH.Text = ParamMax.block_h
  UpdateDistribTab
End Sub

Private Sub e_BlockW_LostFocus()
  'On Error Resume Next
  If Val(e_BlockW.Text) <= ParamMin.block_w Then e_BlockW.Text = ParamMin.block_w
  If Val(e_BlockW.Text) > ParamMax.block_w Then e_BlockW.Text = ParamMax.block_w
  UpdateDistribTab
End Sub

Private Sub e_MaxThreads_Change()
  'On Error Resume Next
  If Val(e_MaxThreads.Text) <= ParamMin.max_threads Then e_MaxThreads.Text = ParamMin.max_threads
  If Val(e_MaxThreads.Text) > ParamMax.max_threads Then e_MaxThreads.Text = ParamMax.max_threads
End Sub

Private Sub UpdateDistribTab()
' zeigt Infos zur Verteilung
  el_PicSize.Text = Str$(e_PicWidth.Text) + " x" + Str$(e_PicHeight.Text)
  el_BlockSize.Text = Str$(e_BlockW.Text) + " x" + Str$(e_BlockH.Text)
  ' ThreadsTotal greift auf globale Parameterstruktur zu
  ' --> sichern der aktuellen Parameter, �bertragen der Eingaben
  '     in Parameter, wiederherstellen der vorherigen Parameter
  '     da eine wirkliche �bernahme ja erst bei "OK" geschehen soll
  Dim tmp As t_Parameters
  tmp = Param           ' aktuelle sichern
  Param = GetParameters ' �bertragen
  el_NrOfThreads.Text = f_main.ThreadsTotal()
  Param = tmp           ' wiederherstellen
End Sub


'--------------------------------------------------------------------
'
' PARAMETER BILDGR��E
'
'--------------------------------------------------------------------

Private Sub chk_sizeprop_Click()
  'e_PicWidth_Change
  e_PicHeight.Enabled = Not e_PicHeight.Enabled
  If Not e_PicHeight.Enabled Then e_PicHeight.Text = e_PicWidth.Text
  e_PicWidth_LostFocus
End Sub

Private Sub e_PicWidth_Change()
  'If Not e_PicHeight.Enabled Then e_PicHeight.Text = e_PicWidth.Text
End Sub

Private Sub e_PicWidth_LostFocus()
  On Error Resume Next
  'If chk_sizeprop.value = 0 Then e_PicHeight.Text = CInt(e_PicWidth.Text * PicScale)
  
  ' check range
  If e_PicWidth.Text = "" Then e_PicWidth.Text = ParamMin.picSize_x
  If CInt(e_PicWidth.Text) <= ParamMin.picSize_x Then e_PicWidth.Text = ParamMin.picSize_x
  If CInt(e_PicWidth.Text) > ParamMax.picSize_x Then e_PicWidth.Text = ParamMax.picSize_x
    
  If chk_sizeprop = 0 Then
    e_PicHeight.Text = e_PicWidth.Text * PicScale
  
    If e_PicHeight.Text > ParamMax.picSize_y Then
      e_PicHeight.Text = ParamMax.picSize_y
      If chk_sizeprop.value = 0 Then
        e_PicWidth.Text = e_PicHeight.Text / PicScale
        If e_PicWidth.Text < ParamMin.picSize_x Then
          chk_sizeprop.value = 1
          e_PicWidth.Text = ParamMin.picSize_x
        End If
      End If
    End If
  End If
  UpdateDistribTab
End Sub

Private Sub e_PicHeight_LostFocus()
  On Error Resume Next
  'If chk_sizeprop.value = 0 Then e_PicWidth.Text = CInt(e_PicHeight.Text * PicScale)
  
  If e_PicHeight.Text = "" Then e_PicHeight.Text = ParamMin.picSize_y
  
  If CInt(e_PicHeight.Text) <= 0 Then e_PicHeight.Text = ParamMin.picSize_y
  If CInt(e_PicHeight.Text) > MinV(ParamMax.picSize_x, ParamMax.picSize_y) Then
    e_PicHeight.Text = MinV(ParamMax.picSize_x, ParamMax.picSize_y)
    'If e_PicWidth.Text > e_PicHeight.Text Then e_PicWidth.Text = e_PicHeight.Text
  End If
  
  UpdateDistribTab
End Sub

Private Function PicScale() As Double
' berechnet Seitenverh�ltnis des Ausgabebereichs
  PicScale = sf_DragBox.height / sf_DragBox.width
End Function

Private Sub UpdatePicSize()
  e_PicWidth_LostFocus
  SetParamMinMax  ' update von max. Blocksize
End Sub


'--------------------------------------------------------------------
'
' PARAMETER SCHNITTSTELLE
'
'--------------------------------------------------------------------

Private Function GetParameters() As t_Parameters
' liest Werte aus Formular in Param ein
  Dim p As t_Parameters
  p.block_w = e_BlockW.Text
  p.block_h = e_BlockH.Text
  p.imag_max = e_imag_max.Text
  p.imag_min = e_imag_min.Text
  p.real_max = e_real_max.Text
  p.real_min = e_real_min.Text
  p.max_threads = e_MaxThreads.Text
  p.max_iter = e_MaxIter.Text
  p.picSize_x = e_PicWidth.Text
  p.picSize_y = e_PicHeight.Text
  p.sizeprop = chk_sizeprop.value
  p.distActive = chk_EnableDist.value
  p.colorchange = e_ColChange.Text
  p.coloroffset = e_ColOffset.Text
  If ColorOption1.value = True Then p.colordepth = 1
  If ColorOption4.value = True Then p.colordepth = 4
  If ColorOption8.value = True Then p.colordepth = 8
  If ColorOption16.value = True Then p.colordepth = 16
  GetParameters = p
End Function

Private Sub SetParameters()
' liest Werte aus Param in Formular ein
  e_BlockW.Text = Param.block_w
  e_BlockH.Text = Param.block_h
  e_imag_max.Text = Param.imag_max
  e_imag_min.Text = Param.imag_min
  e_real_max.Text = Param.real_max
  e_real_min.Text = Param.real_min
  e_MaxThreads.Text = Param.max_threads
  e_MaxIter.Text = Param.max_iter
  e_PicWidth.Text = Param.picSize_x
  e_PicHeight.Text = Param.picSize_y
  chk_sizeprop.value = Param.sizeprop
  e_ColOffset.Text = Param.coloroffset
  e_ColChange.Text = Param.colorchange
  Select Case Param.colordepth
     Case 1
        ColorOption1.value = True
     Case 4
        ColorOption4.value = True
     Case 8
        ColorOption8.value = True
     Case 16
        ColorOption16.value = True
  End Select
  chk_EnableDist.value = Abs(CInt(Param.distActive))
End Sub

Private Sub SetParamMinMax()
' setzt Grenzwerte der Parameter
' maximale Werte
  ParamMax.block_w = Param.picSize_x
  ParamMax.block_h = Param.picSize_y
  ParamMax.imag_max = 2#
  ParamMax.imag_min = 1.99
  ParamMax.real_max = 2#
  ParamMax.real_min = 1.99
  ParamMax.max_threads = 60000
  ParamMax.max_iter = 100000
  ParamMax.picSize_x = (Screen.width / 15) - 50
  ParamMax.picSize_y = (Screen.height / 15) - 150
' minimale Werte
  ParamMin.block_w = 3
  ParamMin.block_h = 3
  ParamMin.imag_max = -1.99
  ParamMin.imag_min = -2#
  ParamMin.real_max = -1.99
  ParamMin.real_min = -2#
  ParamMin.max_threads = 1
  ParamMin.max_iter = 20
  ParamMin.picSize_x = 100
  ParamMin.picSize_y = 100
End Sub

Public Sub SetParamStart()
' setzt AnfangsParameter
' -> sp�ter vielleicht laden von Parametern

  Param.block_w = 30
  Param.block_h = 30
  Param.imag_max = 2#
  Param.imag_min = -2#
  Param.real_max = 2#
  Param.real_min = -2#
  Param.max_threads = 10
  Param.max_iter = 100
  Param.picSize_x = 300
  Param.picSize_y = 300
  Param.colorchange = 20
  Param.coloroffset = 3
  Param.sizeprop = 0
  Param.distActive = True
End Sub

Private Sub SetColordepth()
Dim farb_mod
' checken der m�glichen Farbmodi
  farb_mod = farb_modus
    Select Case farb_mod
        Case 2
            ColorOption1.value = True
            ColorOption4.Enabled = False
            ColorOption8.Enabled = False
            ColorOption16.Enabled = False
        Case 16
            ColorOption4.value = True
            ColorOption8.Enabled = False
            ColorOption16.Enabled = False
        Case 256
            ColorOption8.value = True
            ColorOption16.Enabled = False
        Case Else
            ColorOption16.value = True
    End Select
  
End Sub
