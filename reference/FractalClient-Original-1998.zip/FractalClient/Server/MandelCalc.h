// MandelCalc.h : Deklaration von CMandelCalc

#ifndef __MANDELCALC_H_
#define __MANDELCALC_H_


#include "resource.h"       // Hauptsymbole
#include "CPFractalServer.h" // Events
#include "FractalServerCP.h"

#include <map>

/////////////////////////////////////////////////////////////////////////////
// CMandelCalc
class ATL_NO_VTABLE CMandelCalc : 

	public CComDualImpl<IMandelCalc, &IID_IMandelCalc, &LIBID_FRACTALSERVERLib>, 

	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CMandelCalc, &CLSID_MandelCalc>,
	public IConnectionPointContainerImpl<CMandelCalc>,
	public CProxy_IMandelCalcNotify<CMandelCalc>,
    public IProvideClassInfo2Impl<&CLSID_MandelCalc, &DIID__IMandelCalcNotify, &LIBID_FRACTALSERVERLib>
	//public IDispatchImpl<IMandelCalc, &IID_IMandelCalc, &LIBID_FRACTALSERVERLib>
{
public:
	CMandelCalc()
	{
		InitializeCriticalSection(&mutex);
		InitializeCriticalSection(&threadMapMutex);
		InitializeCriticalSection(&comMapMutex);
		InitializeCriticalSection(&slaveMapMutex);
		
	}

	~CMandelCalc()
	{
		DeleteCriticalSection(&mutex);
		DeleteCriticalSection(&threadMapMutex);
		DeleteCriticalSection(&comMapMutex);
		DeleteCriticalSection(&slaveMapMutex);

	}

DECLARE_REGISTRY_RESOURCEID(IDR_MANDELCALC)

BEGIN_COM_MAP(CMandelCalc)
	COM_INTERFACE_ENTRY(IMandelCalc)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IProvideClassInfo)
    COM_INTERFACE_ENTRY(IProvideClassInfo2)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
END_COM_MAP()

BEGIN_CONNECTION_POINT_MAP(CMandelCalc)
    CONNECTION_POINT_ENTRY(DIID__IMandelCalcNotify)
END_CONNECTION_POINT_MAP()


// IMandelCalc
public:
	STDMETHOD(stopCalc)(/*[in]*/  long threadId);

	STDMETHOD(startCalc)(/*[in]*/  long threadId);

	STDMETHOD(prepareCalc)(	/*[in]*/ double re_lo, /*[in]*/ double imag_lo, 
							/*[in]*/ double re_ru, /*[in]*/ double imag_ru, 
							/*[in]*/ long x_pixel, /*[in]*/ long y_pixel, 
							/*[out, retval]*/ long * threadId);
	
	STDMETHOD(get_maxit)(/*[out, retval]*/ long *pVal);

	STDMETHOD(put_maxit)(/*[in]*/ long newVal);

private:
	long maxItteration;

public:
	std::map<long, HANDLE>		threadIdMap;


	std::map<long, IUnknown *>	comMap;

	CRITICAL_SECTION mutex;
	CRITICAL_SECTION threadMapMutex;
	CRITICAL_SECTION comMapMutex;
	CRITICAL_SECTION slaveMapMutex;
};

#endif //__MANDELCALC_H_
