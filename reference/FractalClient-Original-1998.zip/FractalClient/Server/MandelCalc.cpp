//-----------------------------------------------------------------------------
//         Datei: $Archive: /VV/Beispiele/COM/Fractal/FractalServer/MandelCalc.cpp $
//  Erstellt von: Johannes Weigend
//            am: 12.10.1998
// Geaendert von: $Author: Johannes Weigend $
//            am: $Date: 12/11/98 7:26p $
//  Beschreibung: Implementierung des Interfaces IMandelCalc
//       Version: $Revision: 32 $
//     Copyright: sd&m M�nchen, FH Rosenheim 1998
//------------------------------------------------------------------------------


#include "stdafx.h"
#include "FractalServer.h"
#include "FractalSlave/FractalSlave.h"
#include "FractalSlave/FractalSlave_i.c"
#include "MandelCalc.h"
#include "Log.h"


#include <assert.h>

#include <complex>
#include <algorithm>


static LOG	logfile("c:\\FractalServer.log");

#define ASSERT(c)													\
	if ((c) == 0) logfile.write("[Assertion failed]: c## ");		\
	assert(c)


class SlaveReader : public vector<string>
{
public:
	SlaveReader(string filename)
	{	
		fstream fs;
		fs.open(filename.c_str());
		if (fs.is_open())
		{
			while (!fs.eof())
			{
				string line;
				fs >> line;
				push_back(line);
			}
			fs.close();
		}
		else 
		{
			logfile.write("Cant find Slavefile: " + filename);
		}
	}
};

static SlaveReader	slaves("c:\\FractalSlaves.txt"); 


/////////////////////////////////////////////////////////////////////////////
// CMandelCalc


//------------------------------------------------------------------------------
// Property get maxItteration
//------------------------------------------------------------------------------
STDMETHODIMP CMandelCalc::get_maxit(long * pVal)
{
	ASSERT(pVal);

	*pVal = maxItteration;

	return S_OK;
}

//------------------------------------------------------------------------------
// Property put maxItteration
//------------------------------------------------------------------------------
STDMETHODIMP CMandelCalc::put_maxit(long newVal)
{
	ASSERT(newVal > 0);

	maxItteration = newVal;

	return S_OK;
}


//------------------------------------------------------------------------------
// Thread-�bergabeparameter
//------------------------------------------------------------------------------
struct ThreadParams
{
	double re_lo;
	double imag_lo;

	double re_ru;
	double imag_ru;

	long x_pixel;
	long y_pixel;

	CMandelCalc * pThis;
};


//------------------------------------------------------------------------------
// Deklaration der ThreadProc
//------------------------------------------------------------------------------
DWORD WINAPI ThreadProc(  LPVOID lpParameter );


//------------------------------------------------------------------------------
// Starten der Berechnung im neuen Thread
//------------------------------------------------------------------------------
STDMETHODIMP CMandelCalc::prepareCalc(double re_lo, double imag_lo,
									  double re_ru, double imag_ru,
									  long x_pixel, long y_pixel, 
									  long * threadId)
{
	int priors[] =
	{ 
		THREAD_PRIORITY_HIGHEST,
		THREAD_PRIORITY_ABOVE_NORMAL,
		THREAD_PRIORITY_NORMAL,
		THREAD_PRIORITY_BELOW_NORMAL,
		THREAD_PRIORITY_LOWEST
	};
		
	// Pr�fe Parameter auf g�ltigen Bildausschnitt
	ASSERT(re_lo < re_ru && imag_lo > imag_ru);
	ASSERT(x_pixel >= 2 && y_pixel >= 2);
	ASSERT(threadId);

	ThreadParams *  params = new ThreadParams();

	params->re_lo	= re_lo;
	params->imag_lo	= imag_lo;
	
	params->re_ru	= re_ru;
	params->imag_ru	= imag_ru;
	
	params->x_pixel  = x_pixel;
	params->y_pixel  = y_pixel;

	params->pThis    = this;

	// this wurde kopiert !!!
	AddRef();

	DWORD dwthreadID;
	
	// Rechenthread starten ...
	HANDLE hThread = CreateThread(NULL, 0, &ThreadProc, params, CREATE_SUSPENDED, &dwthreadID);
	ASSERT(hThread);

	*threadId = (long) dwthreadID; // Thread-ID zur�ckgeben

	// speichere ThreadID
	EnterCriticalSection(&threadMapMutex);
	threadIdMap[*threadId] = hThread;
	LeaveCriticalSection(&threadMapMutex);

	// Priorit�t darf nicht zu hoch sein
	SetThreadPriority(hThread, THREAD_PRIORITY_BELOW_NORMAL);
	
	return S_OK;
}


//------------------------------------------------------------------------------
// Starte einen Slave
//------------------------------------------------------------------------------
ISlave * findSlave(CMandelCalc * pThis)
{
	ISlave * pSlave = 0;

	// Solange noch kein g�ltiger Slave gefunden wurde
	// und die Tabelle noch gueltige Eintrage enth�lt, versuche Server zu starten
	EnterCriticalSection(&pThis->slaveMapMutex);
	size_t slavesize = slaves.size();
	LeaveCriticalSection(&pThis->slaveMapMutex);
	
	while (pSlave == 0 && slavesize != 0)
	{
		
		// Ringelreihen
		static serverCnt = 0;	
		
		EnterCriticalSection(&pThis->slaveMapMutex);
		string & sName = slaves.at(serverCnt ++ % slavesize);
	
		wchar_t pServer[255] = {0};

		for (int i = 0; i < sName.length(); i++)
			pServer[i] = (wchar_t) sName[i];
		LeaveCriticalSection(&pThis->slaveMapMutex);
		
		MULTI_QI qiResults = {&IID_ISlave, pSlave, S_OK};
		COSERVERINFO info = { 0, pServer, 0, 0 };
	
		// Objekt am RemoteServer erstellen
		HRESULT hrc = CoCreateInstanceEx (CLSID_Slave, NULL, CLSCTX_REMOTE_SERVER, &info, 1, &qiResults);
		if (FAILED(hrc))
		{
			logfile.write(string("Cant start Slave: ") + sName + " RPC-Server not available");		
			// Entferne Eintrag aus der liste
			EnterCriticalSection(&pThis->slaveMapMutex);
			slaves.erase(find(slaves.begin(), slaves.end(), sName));
			LeaveCriticalSection(&pThis->slaveMapMutex);

			continue;
		}
		// Objekt mu� das Interface unterst�tzen
		// Wenns nicht klappt ist irgendetwas oberfaul
		ASSERT(SUCCEEDED(qiResults.hr));
		pSlave = (ISlave *) qiResults.pItf;		
	
		EnterCriticalSection(&pThis->slaveMapMutex);
		slavesize = slaves.size();
		LeaveCriticalSection(&pThis->slaveMapMutex);
	}


	
	// Noch kein g�ltiger Slave gefunden
	if (pSlave == 0 && slaves.size() == 0)
	{
		// Objekt lokal erstellen
		HRESULT hrc = CoCreateInstance (CLSID_Slave, NULL, CLSCTX_LOCAL_SERVER, IID_ISlave, (void **)&pSlave);
		if (FAILED(hrc))
		{
				logfile.write("Can not start local Slave");
		}

		// Wenn kein Remote-Server verf�gbar ist, mu� der Slave lokal erstellt werden k�nnen
		ASSERT(SUCCEEDED(hrc));
	
	}

	ASSERT(pSlave);

	return pSlave;
}



//------------------------------------------------------------------------------
// ThreadProc
//------------------------------------------------------------------------------
DWORD WINAPI ThreadProc(  LPVOID lpParameter )
{
	// Apartment mu� noch initialsisiert werden
	HRESULT hr = CoInitializeEx(0, COINIT_MULTITHREADED);
	if (FAILED(hr)) return 0;

	// Parameter entpacken	
	ThreadParams params;
	ASSERT (lpParameter);
	params = *(ThreadParams *) lpParameter;
	delete (ThreadParams *) lpParameter;	// freigeben

	ISlave * pSlave = 0;
	SAFEARRAY * psa = 0;	
	
	// Slave suchen
	pSlave = findSlave(params.pThis);

	EnterCriticalSection(&params.pThis->mutex);	
	params.pThis->comMap[GetCurrentThreadId()] = pSlave;	
	LeaveCriticalSection(&params.pThis->mutex);

	long maxitteration;
	params.pThis->get_maxit(&maxitteration);

	HRESULT hrc = pSlave->startCalc(maxitteration, params.re_lo, params.re_ru, params.imag_lo, params.imag_ru, params.x_pixel, params.y_pixel,  &psa);
	if (FAILED(hrc))
	{
		logfile.write("Calculation failed");		
	}
	ASSERT(SUCCEEDED(hrc));
		
	// EnterCriticalSection(&params.pThis->mutex);
	
	// Sink (Client) benachrichtigen
	params.pThis->Fire_result(&psa, GetCurrentThreadId());

	hrc = pSlave->Release();
	ASSERT(SUCCEEDED(hrc));

	DWORD tid = GetCurrentThreadId();

	// Enferne Eintrag aus der comMap
	EnterCriticalSection(&params.pThis->comMapMutex);
	if (params.pThis->comMap[tid])
	{	
		params.pThis->comMap.erase(tid);
	}
	LeaveCriticalSection(&params.pThis->comMapMutex);
	
	// Aufr�umen 
	params.pThis->Release();

	if (psa) hr = SafeArrayDestroy( psa );
	ASSERT (SUCCEEDED(hr));

	EnterCriticalSection(&params.pThis->threadMapMutex);
	HANDLE threadHandle = params.pThis->threadIdMap[tid];
	params.pThis->threadIdMap.erase(tid);
	LeaveCriticalSection(&params.pThis->threadMapMutex);

	CloseHandle(threadHandle);

	// LeaveCriticalSection(&params.pThis->mutex);

	CoUninitialize();

	return 1;
}


//------------------------------------------------------------------------------
// stopCalc
//------------------------------------------------------------------------------
STDMETHODIMP CMandelCalc::stopCalc(long threadId)
{	
	
	// stop Thread	
	// EnterCriticalSection(&mutex);

	EnterCriticalSection(&threadMapMutex);
	HANDLE threadHandle = threadIdMap[threadId];
	LeaveCriticalSection(&threadMapMutex);

	if (threadHandle)
	{
		if (TerminateThread(threadHandle, 0))
		{
			// Com Ref-Counter herunterz�hlen	
			
			EnterCriticalSection(&comMapMutex);
			IUnknown * pSlave = comMap[threadId];

			if (pSlave) pSlave->Release();
			if (comMap[threadId]) 
			{
				comMap.erase(threadId);
			}
			LeaveCriticalSection(&comMapMutex);

			Release();	//  ??? 
		}		

		EnterCriticalSection(&threadMapMutex);
		if (threadIdMap[threadId]) 
		{
			threadIdMap.erase(threadId);
		}		
		LeaveCriticalSection(&threadMapMutex);
		
		CloseHandle(threadHandle);
	}	
	// LeaveCriticalSection(&mutex);
  
	return S_OK;
}


//------------------------------------------------------------------------------
// startCalc
//------------------------------------------------------------------------------
STDMETHODIMP CMandelCalc::startCalc(long threadId)
{	
	// stop Thread	
	EnterCriticalSection(&threadMapMutex);
	HANDLE threadHandle = threadIdMap[threadId];
	LeaveCriticalSection(&threadMapMutex);

	if (threadHandle)
	{
		ResumeThread(threadHandle);
	}


	return S_OK;
}

