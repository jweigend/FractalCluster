Attribute VB_Name = "Module1"
Declare Function SetPixelV Lib "gdi32" (ByVal hdc As Long, ByVal x As Long, ByVal y As Long, ByVal crColor As Long) As Long
Declare Function BitBlt Lib "gdi32" (ByVal dest_hdc As Long, ByVal dest_x As Long, ByVal dest_y As Long, ByVal dest_w As Long, ByVal dest_h As Long, ByVal src_hdc As Long, ByVal src_x As Long, ByVal src_y As Long, ByVal cpyopt As Long) As Long

Public Type t_ThreadTable
  threadNr As Long      ' interne Nummer des Threads
  threadID As Long      ' Thread-ID die vom Server zur�ckgegeben wurde
  threadStarted As Boolean
  threadReturned As Boolean
  valueCount As Long
  b_real_min As Double  ' real/imag Werte dieses Blocks (thread)
  b_real_max As Double
  b_imag_min As Double
  b_imag_max As Double
  start_x As Integer    ' start-koordinaten dieses Blocks ("pixels")
  start_y As Integer    '
  block_w As Integer    ' Gr��e des Blocks
  block_h As Integer    ' (width/height)
End Type

Public Type t_Parameters
  real_min As Double
  real_max As Double
  imag_min As Double
  imag_max As Double
  block_w As Integer
  block_h As Integer
  max_iter As Integer
  max_threads As Integer
End Type

Public Type t_Global
  CalcStopped As Boolean
  CalcRunning As Boolean
  CalcStoppedVerify As Boolean
  threadCount As Long
  threadsRunning As Long
  threadsInDraw As Long
  threadsReturned As Long
  fsize_x As Integer    ' Bildgr��e des Fractals
  fsize_y As Integer
End Type




'Private Sub RemoveThreadTableEntry(ByVal tid As Long)
'  g_tc = g_threadCount
'    For c = 1 To g_tc
'      If ThreadTable(c).threadID = tid Then
        'Call SetThreadTableEntry(ThreadTable(g_tc).imag_max, ThreadTable(g_tc).imag_min, ThreadTable(g_tc).real_max, ThreadTable(g_tc).real_min, ThreadTable(g_tc).threadID, c, ThreadTable(g_tc).x, ThreadTable(g_tc).y)
'        If g_tc <> c Then
'          ThreadTable(c) = ThreadTable(g_tc)
'          ThreadTable(c).threadNr = c
'        End If
        'LBThreadTable.RemoveItem (c - 1)
        'If c - 1 > 0 Then LBThreadTable.RemoveItem (g_tc - 1)
        'If g_tc - 1 > 0 Then
        '  LBThreadTable.AddItem Str$(c) + " " + Str$(ThreadTable(g_tc).threadID), c - 1
        'End If
'        g_threadCount = g_threadCount - 1
'        ReDim ThreadTable(g_threadCount)
'        buildLBThreadTable
'        Exit For
'      End If
'    Next
'End Sub
