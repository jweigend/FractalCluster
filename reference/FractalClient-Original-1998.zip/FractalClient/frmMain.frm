VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form f_main 
   Caption         =   "FractalClient"
   ClientHeight    =   8430
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   10695
   LinkTopic       =   "Form1"
   ScaleHeight     =   8430
   ScaleWidth      =   10695
   StartUpPosition =   3  'Windows-Standard
   Begin MSComctlLib.StatusBar sbStatusBar 
      Align           =   2  'Unten ausrichten
      Height          =   270
      Left            =   0
      TabIndex        =   0
      Top             =   8160
      Width           =   10695
      _ExtentX        =   18865
      _ExtentY        =   476
      Style           =   1
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   13229
            Text            =   "Status"
            TextSave        =   "Status"
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   6
            AutoSize        =   2
            TextSave        =   "23.11.98"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   5
            AutoSize        =   2
            TextSave        =   "20:10"
         EndProperty
      EndProperty
   End
   Begin MSComDlg.CommonDialog dlgCommonDialog 
      Left            =   3120
      Top             =   2040
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin MSComctlLib.ImageList imlToolbarIcons 
      Left            =   2520
      Top             =   2040
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   13
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0000
            Key             =   "New"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0112
            Key             =   "Open"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0224
            Key             =   "Save"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0336
            Key             =   "Print"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0448
            Key             =   "Cut"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":055A
            Key             =   "Copy"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":066C
            Key             =   "Paste"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":077E
            Key             =   "Bold"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0890
            Key             =   "Italic"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":09A2
            Key             =   "Underline"
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0AB4
            Key             =   "Align Left"
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0BC6
            Key             =   "Center"
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0CD8
            Key             =   "Align Right"
         EndProperty
      EndProperty
   End
   Begin VB.Menu m_datei 
      Caption         =   "&Datei"
      Begin VB.Menu m_ende 
         Caption         =   "&Beenden"
      End
   End
   Begin VB.Menu m_fraktal 
      Caption         =   "&Fraktal"
      Begin VB.Menu m_form1 
         Caption         =   "Form1"
      End
      Begin VB.Menu m_parameter 
         Caption         =   "&Parameter..."
      End
      Begin VB.Menu Trennzeichen 
         Caption         =   "-"
      End
      Begin VB.Menu m_startCalculation 
         Caption         =   "starte Berechnung"
      End
   End
   Begin VB.Menu m_ansicht 
      Caption         =   "&Ansicht"
      Begin VB.Menu m_viewTool 
         Caption         =   "&Symbolleiste"
         Checked         =   -1  'True
      End
      Begin VB.Menu m_viewStatus 
         Caption         =   "Status&leiste"
         Checked         =   -1  'True
      End
   End
End
Attribute VB_Name = "f_main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function OSWinHelp% Lib "user32" Alias "WinHelpA" (ByVal hwnd&, ByVal HelpFile$, ByVal wCommand%, dwData As Any)
'Dim Param As t_Parameters

Private Sub Form_Load()
  Me.Left = GetSetting(App.Title, "Settings", "MainLeft", 1000)
  Me.Top = GetSetting(App.Title, "Settings", "MainTop", 1000)
  Me.width = GetSetting(App.Title, "Settings", "MainWidth", 6500)
  Me.height = GetSetting(App.Title, "Settings", "MainHeight", 6500)
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Dim i As Integer

  'close all sub forms
  'For i = Forms.Count - 1 To 1 Step -1
  '  Unload Forms(i)
  'Next
  If Me.WindowState <> vbMinimized Then
    SaveSetting App.Title, "Settings", "MainLeft", Me.Left
    SaveSetting App.Title, "Settings", "MainTop", Me.Top
    SaveSetting App.Title, "Settings", "MainWidth", Me.width
    SaveSetting App.Title, "Settings", "MainHeight", Me.height
  End If
End Sub

Private Sub tbToolBar_ButtonClick(ByVal Button As MSComctlLib.Button)
  On Error Resume Next
  Select Case Button.Key
    Case "Neu"
      'Zu erledigen: Schaltfl�chencode f�r 'Neu' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Neu' hinzuf�gen."
    Case "�ffnen"
      'Zu erledigen: Schaltfl�chencode f�r '�ffnen' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r '�ffnen' hinzuf�gen."
    Case "Speichern"
      'Zu erledigen: Schaltfl�chencode f�r 'Speichern' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Speichern' hinzuf�gen."
    Case "Drucken"
      mnuFilePrint_Click
    Case "Ausschneiden"
      mnuEditCut_Click
    Case "Kopieren"
      mnuEditCopy_Click
    Case "Einf�gen"
      mnuEditPaste_Click
    Case "Fett"
      'Zu erledigen: Schaltfl�chencode f�r 'Fett' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Fett' hinzuf�gen."
    Case "Kursiv"
      'Zu erledigen: Schaltfl�chencode f�r 'Kursiv' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Kursiv' hinzuf�gen."
    Case "Unterstrichen"
      'Zu erledigen: Schaltfl�chencode f�r 'Unterstrichen' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Unterstrichen' hinzuf�gen."
    Case "Links ausrichten"
      'Zu erledigen: Schaltfl�chencode f�r 'Links ausrichten' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Links ausrichten' hinzuf�gen."
    Case "Zentrieren"
      'Zu erledigen: Schaltfl�chencode f�r 'Zentrieren' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Zentrieren' hinzuf�gen."
    Case "Rechts ausrichten"
      'Zu erledigen: Schaltfl�chencode f�r 'Rechts ausrichten' hinzuf�gen.
      MsgBox "Schaltfl�chencode f�r 'Rechts ausrichten' hinzuf�gen."
  End Select
End Sub

Private Sub mnuHelpAbout_Click()
  MsgBox "Version " & App.Major & "." & App.Minor & "." & App.Revision
End Sub

Private Sub mnuHelpSearchForHelpOn_Click()
  Dim nRet As Integer

  'Falls f�r dieses Projekt keine Hilfedatei angegeben
  'ist, wird dem Benutzer eine Meldung angezeigt.
  'Sie k�nnen die Hilfedatei f�r Ihre Anwendung im
  'Dialogfeld Projekteigenschaften festlegen
  If Len(App.HelpFile) = 0 Then
    MsgBox "Hilfeinhalt konnte nicht angezeigt werden. Dieser Anwendung ist keine Hilfedatei zugeordnet.", vbInformation, Me.Caption
  Else
    On Error Resume Next
    nRet = OSWinHelp(Me.hwnd, App.HelpFile, 261, 0)
    If Err Then
      MsgBox Err.Description
    End If
  End If

End Sub

Private Sub mnuHelpContents_Click()
  Dim nRet As Integer

  'Falls f�r dieses Projekt keine Hilfedatei angegeben
  'ist, wird dem Benutzer eine Meldung angezeigt.
  'Sie k�nnen die Hilfedatei f�r Ihre Anwendung im
  'Dialogfeld Projekteigenschaften festlegen
  If Len(App.HelpFile) = 0 Then
    MsgBox "Hilfeinhalt konnte nicht angezeigt werden. Dieser Anwendung ist keine Hilfedatei zugeordnet.", vbInformation, Me.Caption
  Else
    On Error Resume Next
    nRet = OSWinHelp(Me.hwnd, App.HelpFile, 3, 0)
    If Err Then
      MsgBox Err.Description
    End If
  End If

End Sub


Private Sub mnuViewOptions_Click()
  'Zu erledigen: Code f�r 'mnuViewOptions_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuViewOptions_Click' hinzuf�gen."
End Sub

Private Sub mnuViewRefresh_Click()
  'Zu erledigen: Code f�r 'mnuViewRefresh_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuViewRefresh_Click' hinzuf�gen."
End Sub

Private Sub mnuViewStatusBar_Click()
  mnuViewStatusBar.Checked = Not mnuViewStatusBar.Checked
  sbStatusBar.Visible = mnuViewStatusBar.Checked
End Sub

Private Sub mnuViewToolbar_Click()
  mnuViewToolbar.Checked = Not mnuViewToolbar.Checked
  tbToolBar.Visible = mnuViewToolbar.Checked
End Sub

Private Sub mnuEditPasteSpecial_Click()
  'Zu erledigen: Code f�r 'mnuEditPasteSpecial_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuEditPasteSpecial_Click' hinzuf�gen."
End Sub

Private Sub mnuEditPaste_Click()
  'Zu erledigen: Code f�r 'mnuEditPaste_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuEditPaste_Click' hinzuf�gen."
End Sub

Private Sub mnuEditCopy_Click()
  'Zu erledigen: Code f�r 'mnuEditCopy_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuEditCopy_Click' hinzuf�gen."
End Sub

Private Sub mnuEditCut_Click()
  'Zu erledigen: Code f�r 'mnuEditCut_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuEditCut_Click' hinzuf�gen."
End Sub

Private Sub mnuEditUndo_Click()
  'Zu erledigen: Code f�r 'mnuEditUndo_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuEditUndo_Click' hinzuf�gen."
End Sub

Private Sub mnuFileExit_Click()
  'Formular entladen
  Unload Me

End Sub

Private Sub mnuFilePrint_Click()
  'Zu erledigen: Code f�r 'mnuFilePrint_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuFilePrint_Click' hinzuf�gen."
End Sub

Private Sub mnuFileSaveAs_Click()
  'Zu erledigen: Code f�r 'mnuFileSaveAs_Click' hinzuf�gen.
  MsgBox "Code f�r 'mnuFileSaveAs_Click' hinzuf�gen."
End Sub

Private Sub m_form1_Click()
  Dim ff As Form1
  Set ff = New Form1
  Load ff
  ff.Show
  
End Sub

Private Sub m_parameter_Click()
' zeigt Parameterdialog
  Dim fp As f_Parameter
  Set fp = New f_Parameter
  Load fp
  fp.Show vbModal
End Sub
